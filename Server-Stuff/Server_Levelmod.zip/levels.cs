


//Made by Eagle517 and ºÀjc433º

package Levelmod

{

function GameConnection::onClientLeaveGame(%client)

{

    parent::onClientLeaveGame(%client);

    %fw = new FileObject();

 %fw.openForWrite("config/server/Levels/"@%client.BL_ID@".txt");

    %fw.writeLine(%client.level);

    %fw.close();

    %fw.delete();

        %file = new fileObject();

        %file.openforAppend("config/server/levels/"@%client.BL_ID@".txt");

        %file.writeLine(%client.levelXP);

        %file.close();

        %file.delete();

    %fb = new fileObject();

    %fb.openForAppend("config/server/levels/"@%client.BL_ID@".txt");

    %fb.writeLine(%client.totalXP);

    %fb.close();

    %fb.delete();

}






function GameConnection::onClientEnterGame(%client)

{

        parent::OnClientEnterGame(%client);

        %client.oldPre = %client.clanPrefix;

    if(%client.level > 1)

        {

        %file = new fileobject();

        %file.openforread("config/server/levels/"@%client.BL_ID@".txt");

        while(!%file.isEOF())

        {

            %line = %file.readline();

            %name = getword(%line,0);

            if(%name == %client.level)

            {

                %client.level = %client.level;

            }

            if(%name == %client.levelXP)

            {

                %client.levelXP = %client.levelXP;

            }

            if(%name == %client.totalXP)

            {

                %client.totalXp = %client.totalXP;

            }

        }

        %client.clanPrefix=("[\c6"@%client.level@"\c7] "@%client.oldPre);

         %file.close();

        %file.delete();

    }

    else if(%client.level = 1)

    {

        %client.clanPrefix=("[\c61\c7]  "@%client.oldPre);

    }

}






function gameConnection::onDeath(%vict,%client)

{

 parent::onDeath(%vic,%client)

 %vic = findClientByName(%vict);

 if(%vic.levelXP > %vic.levelMustXP)

 {

  announce("\c4"@ %vict @"\c2 has gone up a level and is now level \c3"@ %vic.level @"\c2.");

  %vic.level++;

  %vic.levelXP=0;

  %vic.levelMustXP++;

 }

 else

 {

  %vic.levelXP++;

  messageClient(%client,'',"\c3"@ %client.levelXP" \ "@ %client.levelMustXP @".");

 }

}

};

activatePackage(Levelmod);