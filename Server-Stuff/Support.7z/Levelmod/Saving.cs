package Saving
{
    function saveEverything(%client)
    {
        %client.DBSet("Joined",%client.joinedTimes,1);

        %client.DBSet("level",%client.level,1);
        %client.DBSet("levelEXP",%client.EXP,1);
        %client.DBSet("levelMaxEXP",%client.MaxEXP,1);
        %client.DBSet("LevelColor",%client.LevelColor,1);
        
        %client.DBSet("Knives",%client.knifecount,1);
    }
    
    function loadEverything(%client)
    {
        %client.level = %client.DBget("level");
        %client.EXP = %client.DBget("levelEXP");
        %client.MaxEXP = %client.DBget("levelMaxEXP");
        %client.levelColor = %client.DBget("LevelColor");
        
        if(%client.isAdmin)
            giveAward(%client, "Admin");
        if(%client.isSuperAdmin)
            giveAward(%client, "Super Admin");

        %client.KnifeCount = %client.DBget("Knives");
        if(%client.KnifeCount <= 0)
            %client.KnifeCount = 1;

        %client.joinedTimes = %client.DBget("Joined");
        %client.joinedTimes++;
        if(!%client.joinedTimes)
            %client.joinedTimes = 1;
        if(%client.joinedTimes >= 50)
            giveAward(%client,"Joined 50 times before");
        if(%client.joinedTimes >= 100)
            giveAward(%client,"Joined 100 times before");

        %client.clanPrefix = "\c6[\c4" @ %client.LevelColor @ %client.level @ "\c6] \c7" @ %client.clanOldP;
        quickPrefix(%client);
    }
    
    function GameConnection::autoAdminCheck(%client)
    {
         parent::autoAdminCheck(%client);
         schedule(100,0,loadEverything,%client);
    }
    function GameConnection::onClientLeaveGame(%client)
    {
        saveEverything(%client);
        parent::onClientLeaveGame(%client);
    }
};
activatePackage(Saving);
