if($GamemodeArg $= "Add-ons/gamemode_KnifeTDM/gamemode.txt")
{
	$Rank[0] = "Blockhead";
	$RankColor[0] = "<color:0066CC>";

	$Rank[1] = "Knifer";
	$RankColor[1] = "<color:009933>";

	$Rank[2] = "Legit";
	$RankColor[2] = "<color:800000>";

	$Rank[3] = "CrAzY";
	$RankColor[3] = "<color:333399>";

	$Rank[4] = "Killer";
	$RankColor[4] = "<color:CCCC66>";

	$Rank[5] = "Nightmare";
	$RankColor[5] = "<color:660066>";

	$Rank[6] = "Of the Devil";
	$RankColor[6] = "<color:000099>";

	$Rank[7] = "Out of the Mist";
	$RankColor[7] = "<color:33CC66>";

	$Rank[8] = "Dark Mist";
	$RankColor[8] = "<color:660000>";

	$Rank[9] = "Devil";
	$RankColor[9] = "<color:00FFFF>";

	$Rank[10] = "Nissa Ravena";
	$RankColor[10] = "<color:33FF00>";

	$Rank[11] = "Crimson";
	$RankColor[11] = "<color:FF0099>";
}
if($GameModeArg $= "Add-Ons/GameMode_Renderhalls/gamemode.txt")
{
	$Rank[0] = "The Victim";
	$RankColor[0] = "<color:0066CC>";

	$Rank[1] = "Undercover";
	$RankColor[1] = "<color:009933>";

	$Rank[2] = "Explorer";
	$RankColor[2] = "<color:800000>";

	$Rank[3] = "A Friendly Ghost";
	$RankColor[3] = "<color:333399>";

	$Rank[4] = "Darkest";
	$RankColor[4] = "<color:CCCC66>";

	$Rank[5] = "Nightmare";
	$RankColor[5] = "<color:660066>";

	$Rank[6] = "Of the Devil";
	$RankColor[6] = "<color:000099>";

	$Rank[7] = "Out of the Mist";
	$RankColor[7] = "<color:33CC66>";

	$Rank[8] = "Dark Mist";
	$RankColor[8] = "<color:660000>";

	$Rank[9] = "Devil";
	$RankColor[9] = "<color:00FFFF>";

	$Rank[10] = "Nissa Ravena";
	$RankColor[10] = "<color:33FF00>";

	$Rank[11] = "Crimson";
	$RankColor[11] = "<color:FF0099>";
}
if($GameModeArg $= "Add-Ons/GameMode_SpeedyKart/gamemode.txt")
{
	$Rank[0] = "Rammer";
	$RankColor[0] = "<color:333333>";

	$Rank[1] = "The Driver";
	$RankColor[1] = "<color:333333>";

	$Rank[2] = "Road-Runner";
	$RankColor[2] = "<color:9999FF>";

	$Rank[3] = "Off Roader";
	$RankColor[3] = "<color:66CC66>";

	$Rank[4] = "Clean Racer";
	$RankColor[4] = "<color:CCCC66>";

	$Rank[5] = "Unramable";
	$RankColor[5] = "<color:660066>";

	$Rank[6] = "God-Like Driver";
	$RankColor[6] = "<color:000099>";

	$Rank[7] = "Overdosage";
	$RankColor[7] = "<color:33CC66>";

	$Rank[8] = "Overlord";
	$RankColor[8] = "<color:660000>";

	$Rank[9] = "God-Like";
	$RankColor[9] = "<color:00FFFF>";

	$Rank[10] = "Emperor";
	$RankColor[10] = "<color:33FF00>";

	$Rank[11] = "Best";
	$RankColor[11] = "<color:FF0099>";
}
package LevelShow
{
	function GameConnection::onClientEnterGame(%client)
	{
		parent::onClientEnterGame(%client);
		if(%client.rankCount < 0 || %client.rankCount $= "")
			%client.rankCount = 0;
		schedule(2000, 0, quickPrefix, %client);
		schedule(1000, 0, showStats, %client);
	}
	
	function showStats(%client)
	{
		
		$GUIfont = "<font:arial:18>";
		$GUISC = "<color:f0f0f0>";
		if(isObject(%client) && isObject(%client.player))
		{
			if(!$Levelmod::isEnabled)
			{
				commandToClient(%client,'bottomprint',"",1,1);
				
				cancel(%client.StatisticsLoop);
				%client.StatisticsLoop = schedule(2000, 0, ShowStats, %client);
				return;
			}
			if($GameModeArg $= "Add-Ons/GameMode_Renderhalls/gamemode.txt")
			{
				if(%client.score <= 20)
				{
					%client.LevelTitle = $Rank[0];
					%client.LevelColor = $RankColor[0];
				}
				if(%client.score == 60)
				{
					if(!%client.unlockedFlashlight)
					{
						%client.unlockedFlashlight = 1;
						messageClient(%client,'',"\c6You've unlocked the \c4Flashlight! \c6Press your light key to enable it.");
						announce("\c4" @%client.name SPC "\c6unlocked the Flashlight!");
					}
					%client.LevelTitle = $Rank[1];
					%client.LevelColor = $RankColor[1];
				}
				if(%client.score == 120)
				{
					%client.LevelTitle = $Rank[2];
					%client.LevelColor = $RankColor[2];
				}
				if(%client.score == 180)
				{
					%client.LevelTitle = $Rank[3];
					%client.LevelColor = $RankColor[3];
				}
				if(%client.score == 250)
				{
					%client.LevelTitle = $Rank[4];
					%client.LevelColor = $RankColor[4];
				}
				if(%client.score == 320)
				{
					%client.LevelTitle = $Rank[5];
					%client.LevelColor = $RankColor[5];
				}
				if(%client.score == 400)
				{
					%client.LevelTitle = $Rank[6];
					%client.LevelColor = $RankColor[6];
				}
				if(%client.score == 490)
				{
					%client.LevelTitle = $Rank[7];
					%client.LevelColor = $RankColor[7];
				}
				if(%client.score == 580)
				{
					%client.LevelTitle = $Rank[8];
					%client.LevelColor = $RankColor[8];
				}
				if(%client.score == 680)
				{
					%client.LevelTitle = $Rank[9];
					%client.LevelColor = $RankColor[9];
				}
			}

			if($GameModeArg $= "Add-Ons/GameMode_KnifeTDM/gamemode.txt")
			{
				if(%client.level == 1)
				{
					%client.LevelTitle = $Rank[0];
					%client.LevelColor = $RankColor[0];
				}
				
				if(%client.level >= 2 && %client.level <= 4)
				{
					%client.LevelTitle = $Rank[1];
					%client.LevelColor = $RankColor[1];
				}
				if(%client.level >= 5 && %client.level <= 9)
				{
					%client.LevelTitle = $Rank[2];
					%client.LevelColor = $RankColor[2];
				}
				if(%client.level >= 10 && %client.level <= 14)
				{
					%client.LevelTitle = $Rank[3];
					%client.LevelColor = $RankColor[3];
				}
				if(%client.level >= 15 && %client.level <= 19)
				{
					%client.LevelTitle = $Rank[4];
					%client.LevelColor = $RankColor[4];
				}
				if(%client.level >= 20 && %client.level <= 24)
				{
					%client.LevelTitle = $Rank[5];
					%client.LevelColor = $RankColor[5];
				}
				if(%client.level >= 25 && %client.level <= 29)
				{
					%client.LevelTitle = $Rank[6];
					%client.LevelColor = $RankColor[6];
				}
				if(%client.level >= 30 && %client.level <= 34)
				{
					%client.LevelTitle = $Rank[7];
					%client.LevelColor = $RankColor[7];
				}
				if(%client.level >= 35 && %client.level <= 39)
				{
					%client.LevelTitle = $Rank[8];
					%client.LevelColor = $RankColor[8];
				}
				if(%client.level >= 40 && %client.level <= 44)
				{
					%client.LevelTitle = $Rank[9];
					%client.LevelColor = $RankColor[9];
				}
				if(%client.level >= 45 && %client.level <= 49)
				{
					%client.LevelTitle = $Rank[10];
					%client.LevelColor = $RankColor[10];
				}
				if(%client.level >= 50 && %client.level <= 54)
				{
					%client.LevelTitle = $Rank[11];
					%client.LevelColor = $RankColor[11];
				}
			}

			if($GameModeArg $= "Add-Ons/GameMode_SpeedyKart/gamemode.txt")
			{
				if(%client.level == 1)
				{
					%client.LevelTitle = $Rank[0];
					%client.LevelColor = $RankColor[0];
				}
				
				if(%client.level >= 2 && %client.level <= 3)
				{
					%client.LevelTitle = $Rank[1];
					%client.LevelColor = $RankColor[1];
				}
				if(%client.level >= 4 && %client.level <= 6)
				{
					%client.LevelTitle = $Rank[2];
					%client.LevelColor = $RankColor[2];
				}
				if(%client.level >= 7 && %client.level <= 9)
				{
					%client.LevelTitle = $Rank[3];
					%client.LevelColor = $RankColor[3];
				}
				if(%client.level >= 10 && %client.level <= 12)
				{
					%client.LevelTitle = $Rank[4];
					%client.LevelColor = $RankColor[4];
				}
				if(%client.level >= 13 && %client.level <= 15)
				{
					%client.LevelTitle = $Rank[5];
					%client.LevelColor = $RankColor[5];
				}
				if(%client.level >= 16 && %client.level <= 18)
				{
					%client.LevelTitle = $Rank[6];
					%client.LevelColor = $RankColor[6];
				}
				if(%client.level >= 19 && %client.level <= 21)
				{
					%client.LevelTitle = $Rank[7];
					%client.LevelColor = $RankColor[7];
				}
				if(%client.level >= 22 && %client.level <= 24)
				{
					%client.LevelTitle = $Rank[8];
					%client.LevelColor = $RankColor[8];
				}
				if(%client.level >= 25 && %client.level <= 27)
				{
					%client.LevelTitle = $Rank[9];
					%client.LevelColor = $RankColor[9];
				}
				if(%client.level >= 28 && %client.level <= 30)
				{
					%client.LevelTitle = $Rank[10];
					%client.LevelColor = $RankColor[10];
				}
				if(%client.level >= 31 && %client.level <= 33)
				{
					%client.LevelTitle = $Rank[11];
					%client.LevelColor = $RankColor[11];
				}
			}

			%C = %client.LevelColor;
			%LV = %client.LevelTitle;
			%LVL = %client.level;
			%XP = %client.EXP;
			%maxXP = %client.MaxEXP;
			if($GameModeArg $= "Add-Ons/GameMode_KnifeTDM/gamemode.txt")
			{
				%text = $GUIfont @ $GUISC @ "<just:center>Rank: " @ %C @ %LV;
				%text = %text SPC "\n\c6Level:" @ %C SPC %LVL;
				%text = %text SPC "\n\c6XP:" @ %C SPC %XP @ " / " @ %C @ %maxXP;
				%text = %text SPC "\n\n\c6Top Knifer: " @ %C @ $serverPlayer @ " [" @ $serverScore @ "] ";
				%text = %text SPC "\n\c6Top Level: " @ %C @ $serverPlayerLevel @ " [" @ $serverLevel @ "]";
				%client.bottomPrint(%text,3,1);
			}
			if($GameModeArg $= "Add-Ons/GameMode_Renderhalls/gamemode.txt")
			{
				%text = $GUIfont @ $GUISC @ "<just:center>Rank: " @ %C @ %LV;
				%text = %text SPC "\n\c6Your Score:" @ %C SPC %client.score;
				%text = %text SPC "\n\c6Your Team:" @ %C SPC "Teams are still being made...";
				%text = %text SPC "\n\n\c6Top Runner: " @ %C @ $serverPlayer @ " [" @ $serverScore @ "] ";
				%client.bottomPrint(%text,3,1);
			}
			if($GameModeArg $= "Add-Ons/GameMode_SpeedyKart/gamemode.txt")
			{
				%text = $GUIfont @ $GUISC @ "<just:center>Rank: " @ %C @ %LV;
				%text = %text SPC "\n\c6Level:" @ %C SPC %LVL;
				%text = %text SPC "\n\c6XP:" @ %C SPC %XP @ " / " @ %C @ %maxXP;
				%text = %text SPC "\n\n\c6Top Driver: " @ %C @ $serverPlayerLevel @ " [" @ $serverLevel @ "]";
				%client.bottomPrint(%text,3,1);
			}
			//commandToClient(%client,'bottomPrint', "<br>" @ $GUIfont @ $GUISC @ "<just:center>Rank: " @ %C @ %LV SPC %SC @ "\c6Level:" @ %C SPC %LVL SPC %SC @ "\c6XP:" @ %C SPC %XP @ %SC @ " / " @ %C @ %maxXP @ "<br><br><just:center>\c6Top Knifer: " @ %C @ $serverPlayer @ " [" @ $serverScore @ "] <br> \c6Top Level: "  @ %C @ $serverPlayerLevel @ " [" @ $serverLevel @ "]",3,1);
				
			
			if(%client.isMember)
				%client.clanSuffix = "\c4GKU";
			
			if(%client.score > $serverScore)
			{
				$serverPlayer = %client.name;
				$serverScore = %client.score;
				
				if(%client.name $= $serverPlayer)
					%skip = 1;
				else
					%skip = 0;
				
				if(!%skip)
					announce("\c4" @ $serverPlayer @ " \c6has gained the most score in the server \c4[" @ $serverScore @ "]");
			}
			if(%client.Level > $serverLevel)
			{
				$serverPlayerLEVEL = %client.name;
				$serverLevel = %client.level;
				
				if(%client.name $= $serverPlayer)
					%skip = 1;
				else
					%skip = 0;
				
				if(!%skip)
					announce("\c4" @ $serverPlayerLevel @ " \c6is the best level in the server! \c4[" @ $serverLevel @ "]");
			}
			cancel(%client.StatisticsLoop);
			%client.StatisticsLoop = schedule(2000, 0, ShowStats, %client);
			return;
		}
		cancel(%client.StatisticsLoop);
		%client.StatisticsLoop = schedule(2000, 0, ShowStats, %client);
	}
};
activatePackage(LevelShow);


