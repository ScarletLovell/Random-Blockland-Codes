exec("./Commands/Guest.cs");
exec("./Commands/Member.cs");
exec("./Commands/VIP.cs");
exec("./Commands/Moderator.cs");
exec("./Commands/Admin.cs");
exec("./Commands/SuperAdmin.cs");
exec("./Commands/None.cs");