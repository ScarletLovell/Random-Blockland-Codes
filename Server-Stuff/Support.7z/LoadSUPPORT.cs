exec("./Awards.cs");
exec("./Chat.cs");
exec("./Ranks.cs");
exec("./Voting.cs");