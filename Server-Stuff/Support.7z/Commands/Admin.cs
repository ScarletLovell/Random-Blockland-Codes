package AdminCMDS
{
	function serverCmdMute(%client, %victim, %time)
	{
		%vict = findClientByName(%victim);

		if(%client.isAdmin || %client.isModerator || %client.isSuperAdmin)
		{
			if(%time $= "" || %time < 30 || %time + 0 !$= %time || %time > 900)
				%time = 30;
			
			if(%vict.isMuted)
			{
				messageClient(%client,'',"\c6This person is already muted!");
				return;
			}
			if(%client.isModerator){
				%time = 30;
				messageClient(%client,'',"\c6Moderators can only mute for 30 seconds.");
			}
			%vict.isMuted = 1;
			$Commands::MuteSchedule[%vict.BL_ID] = schedule(%time*1000, 0, unmute, %vict);
			announce("\c4" @ %vict.name SPC "\c6was muted by\c4" SPC %client.name SPC "\c6for\c4" SPC %time SPC "\c6seconds.");
		}
		else
			messageClient(%client,'',"\c6You are not an admin!");
	}

	function serverCmdUnmute(%client, %victim)
	{
		%vict = findClientByName(%victim);
		if(%vict.isMuted)
		{
			if(%client.isModeartor || %client.isAdmin)
			{
				announce("\c4" @ %vict.name SPC "\c6was unmuted by\c4" SPC %client.name @ ".");
				cancel($Commands::MuteSchedule[%vict.BL_ID]);
				%vict.isMuted = 0;
			}
		}
	}

	function UnMute(%vict)
	{
		%vict.isMuted = 0;
		messageClient(%vict,'',"\c6You are now unmuted.");
		cancel($Commands::MuteSchedule[%vict.BL_ID]);
	}

	function serverCmdCheckping(%client, %victim)
	{
		Commands::sendResult(%client,"Checkping");
		if(%client.isModerator || %client.isAdmin || %client.isSuperAdmin || %client.isCoHost)
		{
			%vict = findClientByName(%victim);
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4" @ %victim @ " \c6is not a valid player.");
				return;
			}
			else
			announce("\c4"@ %client.name @" \c6Checked \c4"@ %vict.name @"\c6's ping: \c4" @ %vict.getPing());
		}
		else
		{
			messageClient(%client,'',"\c6You are not a Moderator or Admin!");
		}
	}

	function serverCmdWarn(%client, %victim, %T1, %T2, %T3, %T4, %T5, %T6)
	{
		%vict = findClientByName(%victim);
		%warnings = trimTrailing(%T1 SPC %T2 SPC %T3 SPC %T4 SPC %T5 SPC %T6);
		Commands::sendResult(%client,"Warn [" @ %vict.name SPC "---" SPC %warnings @ "]");

		if(%client.isModerator || %client.isAdmin || %client.isSuperAdmin || %client.isCoHost)
		{
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4" @ %victim @ " \c6is not a valid player.");
				return;
			}

			if(!%vict.isAdmin || !%vict.isSuperAdmin || %client.isCoHost)
			{
				if(%vict.hasWarning >= 1)
				{
					%vict.hasWarning++;
					if(%vict.hasWarning == 3)
					{
						announce("\c4"@ %vict.name @" \c2has been kicked for too many warnings!");
						%vict.delete("Kicked: " @ %warnings);
					}
					announce("\c4" @ %vict.name @ " \c6was Warned by \c4" @ %client.name @ " \c6for " @ %warnings @ " \c7 Warning " @ %vict.hasWarning @ "\c7");
				}
				else if(%vict.hasWarning <= 1)
				{
					%vict.hasWarning = 1;
					announce("\c4" @ %vict.name @ " \c6was Warned by \c4" @ %client.name @ " \c6for " @ %warnings @ " \c7 Warning " @ %vict.hasWarning @ "\c7");
				}
			}
			else
			{
				messageClient(%client,'',"\c6You can't warn Admins!");
			}
		}
		else
		{
			messageClient(%client,'',"\c6You are not a Mod or Admin");
		}
	}

	function serverCmdForceKill(%client, %victim)
	{
		%vict = findClientByName(%victim);
		Commands::sendResult(%client,"ForceKill [" @ %vict.name @ "]");

		if(%client.isModerator ||%client.isAdmin)
		{
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4" @ %victim @ " \c6is not a valid player.");
				return;
			}
			announce("\c4" @ %client.name @ " \c6force killed \c4" @ %vict.name);
			%vict.player.kill();
		}
	}
	
	
	function servercmdAC(%client, %Chat, %Chat2, %Chat3, %Chat4, %Chat5, %Chat6, %Chat7, %Chat8, %Chat9, %Chat10, %Chat11, %Chat12, %Chat13, %Chat14, %Chat15, %Chat16, %Chat17, %Chat18, %Chat19, %Chat20)
	{
		if(%client.isAdmin)
		{
			%msg = %Chat SPC %Chat2 SPC %Chat3 SPC %Chat4 SPC %Chat5 SPC %Chat6 SPC %Chat7 SPC %Chat8 SPC %Chat9 SPC %Chat10 SPC %Chat11 SPC %Chat12 SPC %Chat13 SPC %Chat14 SPC %Chat15 SPC %Chat16 SPC %Chat17 SPC %Chat18 SPC %Chat19 SPC %Chat20;
			%msg = trim(%msg);

			%count = ClientGroup.getCount();
			for(%cl = 0; %cl < %count; %cl++)
			{
				%clientB = ClientGroup.getObject(%cl);
				if(%clientB.isAdmin)
					messageClient(%clientB, '', "\c6AdminChat(\c4" @ %client.name @ "\c6): " @ %msg);
			}
			echo("AdminChat (" @ %client.name @ "): " @ %msg);
		}

		else
			messageclient(%client, '', "\c6You are not an Admin!");
	}
};
activatePackage(AdminCMDS);