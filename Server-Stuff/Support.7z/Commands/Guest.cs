package GuestCMDS
{
	function serverCmdMyPing(%client)
	{
		messageClient(%client,'',"\c6Your ping is \c4" @ %client.getPing());
	}
	function serverCmdSetTag(%client, %color, %tag)
	{
		%timeOut = 300000;
		%tagLen = 10;
		
		Commands::sendResult(%client, "SetTag");

		if(%color $= "" || %color !$= "wray" || %color !$= "white" || %color !$= "blue" && %color !$= "red" && %color !$= "green" && %color !$= "purple" && %color !$= "yellow" && %color !$= "cyan")
		{
			messageClient(%client,'',"\c6Colors: \c7Gray \c1Blue\c6, \c0Red\c6, \c2Green\c6, \c5Purple\c6, \c4Cyan\c6, \c3Yellow");
			return;
		}

		if(%client.isAdmin)
		{
			%timeOut = 0;
			%tagLen = 15;
		}
		%color = stripMLControlChars(%color);
		if(%color $= "red")
			%color = "\c0";
		if(%color $= "blue")
			%color = "\c1";
		if(%color $= "green")
			%color = "\c2";
		if(%color $= "yellow")
			%color = "\c3";
		if(%color $= "cyan")
			%color = "\c4";
		if(%color $= "purple")
			%color = "\c5";
		if(%color $= "white")
			%color = "\c6";
		if(%color $= "gray")
			%color = "\c7";
		
		if(getSimTime() - %client.prefixTimeOut < %timeOut)
		{
			messageClient(%client, '', "\c6You must wait 5 minutes to change your tag again!");
			return;
		}

		if(strLen(%tag) >= %tagLen)
		{
			messageClient(%client, '', "\c6Your tag cannot be more than " @ %tagLen @ " charatcers long!");
			return;
		}
		%tag = stripMLControlChars(%tag);
		
		%client.clanOldP = %color @ %tag;
		%client.clanPrefix = %color @ %tag;
		%client.prefixTimeOut = getSimTime();
		quickPrefix(%client);

		messageClient(%client, '', "\c6Prefix changed to" SPC %color @ %tag);
	}

	function serverCmdAFK(%client, %r1, %r2, %r3, %r4, %r5, %r6, %r7, %r8, %r9, %r10)
	{
		if(%client.isMuted)
		{
			messageClient(%client, '', "\c6You cannot use this command while muted");
			return;
		}

		if(%client.isAFK)
		{
			messageClient(%client,'',"\c6You are already AFK!");
			return;
		}
		
		%reason = stripMLControlChars(%r1 SPC %r2 SPC %r3 SPC %r4 SPC %r5 SPC %r6 SPC %r7 SPC %r8 SPC %r9 SPC %r10);
		%reason = trim(%reason);

		if(%reason $= "")
		{
			announce("\c4" @ %client.name SPC "\c6is now AFK: \c4Away From Keyboard");
			%client.isAFK = 1;
			return;
		}
		
		announce("\c4" @ %client.name SPC "\c6is now AFK: \c4" @ %reason);
		%client.isAFK = 1;
	}

	function serverCmdBRB(%client, %r1, %r2, %r3, %r4, %r5, %r6, %r7, %r8, %r9, %r10)
	{
		if(%client.isMuted)
		{
			messageClient(%client, '', "\c6You cannot use this command while muted");
			return;
		}

		if(%client.isAFK)
		{
			messageClient(%client,'',"\c6You are already AFK!");
			return;
		}
		
		%reason = stripMLControlChars(%r1 SPC %r2 SPC %r3 SPC %r4 SPC %r5 SPC %r6 SPC %r7 SPC %r8 SPC %r9 SPC %r10);
		%reason = trim(%reason);

		if(%reason $= "")
		{
			announce("\c4" @%client.name SPC "\c6is now AFK: \c4Be Right Back!");
			%client.isAFK = 1;
			return;
		}
		
		announce("\c4" @%client.name SPC "\c6will Be Right Back: \c4" @ %reason);
		%client.isAFK = 1;
	}

	function serverCmdBack(%client)
	{
		if(%client.isAFK)
		{
			announce("\c4" @ %client.name SPC "\c6is back!");
			%client.isAFK = 0;
			return;
		}
		messageClient(%client,'',"\c6You are not away!");
	}
	
	function serverCmdPM(%client, %victim, %r1, %r2, %r3, %r4, %r5, %r6, %r7, %r8, %r9, %r10, %r11, %r12, %r13, %r14, %r15, %r16, %r17, %r18, %r19, %r20)
	{
		%victim = findClientByName(%victim);

		%PMTimeout = 2000;
		if(%client.isAdmin)
			%PMTimeout = 0;
		
		if(getSimTime() - %client.PMTimeout < %PMTimeout)
		{
			messageClient(%client,'',"\c6You must wait \c42 \c6seconds to PM again!");
			return;
		}

		%reason = stripMLControlChars(%r1 SPC %r2 SPC %r3 SPC %r4 SPC %r5 SPC %r6 SPC %r7 SPC %r8 SPC %r9 SPC %r10 SPC %r11 SPC %r12 SPC %r13 SPC %r14 SPC %r15 SPC %r16 SPC %r17 SPC %r18 SPC %r19 SPC %r20);
		%reason = trim(%reason);
		
		messageClient(%victim,'',"\c4From" SPC %client.name SPC "\c6:" SPC %reason);
		messageClient(%client,'',"\c4Sent To" SPC %victim.name SPC "\c6:" SPC %reason);
		echo(getDateTime());
		echo(%client.name SPC "MSG to" SPC %client.name SPC "from" SPC %victim.name);
		echo(%reason);

		logPM(%client, %victim, %reason);

		%client.PMTimeout = getSimTime();
	}
	function serverCmdLol(%client)
	{
		Commands::sendResult(%client,"Lol");

		if(%client.hasLoled)
		{
			messageClient(%client,'',"\c6You must wait \c415 \c6seconds to LoL again!");
			return;
		}

		announce("\c4"@ %client.name @" \c6has Loled!!");
		%client.hasLoled = 1;
		schedule(15000, 0, CoolDownCommands, %client, 1);
	}

	function serverCmdSetTag(%client, %color, %tag)
	{
		%timeOut = 300000;
		%tagLen = 10;
		
		Commands::sendResult(%client, "SetTag");

		if(%color $= "" || %color !$= "wray" || %color !$= "white" || %color !$= "blue" && %color !$= "red" && %color !$= "green" && %color !$= "purple" && %color !$= "yellow" && %color !$= "cyan")
		{
			messageClient(%client,'',"\c6Colors: \c7Gray \c1Blue\c6, \c0Red\c6, \c2Green\c6, \c5Purple\c6, \c4Cyan\c6, \c3Yellow");
			return;
		}

		if(%client.isAdmin)
		{
			%timeOut = 0;
			%tagLen = 15;
		}
		%color = stripMLControlChars(%color);
		if(%color $= "red")
			%color = "\c0";
		if(%color $= "blue")
			%color = "\c1";
		if(%color $= "green")
			%color = "\c2";
		if(%color $= "yellow")
			%color = "\c3";
		if(%color $= "cyan")
			%color = "\c4";
		if(%color $= "purple")
			%color = "\c5";
		if(%color $= "white")
			%color = "\c6";
		if(%color $= "gray")
			%color = "\c7";
		
		if(getSimTime() - %client.prefixTimeOut < %timeOut)
		{
			messageClient(%client, '', "\c6You must wait 5 minutes to change your tag again!");
			return;
		}

		if(strLen(%tag) >= %tagLen)
		{
			messageClient(%client, '', "\c6Your tag cannot be more than " @ %tagLen @ " charatcers long!");
			return;
		}
		%tag = stripMLControlChars(%tag);
		
		%client.clanOldP = %color @ %tag;
		%client.clanPrefix = %color @ %tag;
		%client.prefixTimeOut = getSimTime();
		quickPrefix(%client);

		messageClient(%client, '', "\c6Prefix changed to" SPC %color @ %tag);
	}
};
activatePackage(GuestCMDS);