package SuperAdminCMDS
{
	function serverCmdResetAwards(%client, %victim)
	{
		Commands::sendResult(%client,"ResetAwards");
		if(%client.isSuperAdmin || %client.isCoHost)
		{
			%vict = findClientByName(%victim);
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4"@ %victim @" \c6is not a valid player.");
				return;
			}
			else
			{
				fileDelete("config/server/Awards/" @ %vict.BL_ID @ ".txt");
				announce("\c4" @ %vict.name @ "\c6's awards were Reset by \c4" @ %client.name);
			}
		}
	}
};
activatePackage(SuperAdminCMDS);