package ModeratorCMDS
{
	function serverCmdMC(%client, %Chat, %Chat2, %Chat3, %Chat4, %Chat5, %Chat6, %Chat7, %Chat8, %Chat9, %Chat10, %Chat11, %Chat12, %Chat13, %Chat14, %Chat15, %Chat16, %Chat17, %Chat18, %Chat19, %Chat20)
	{
		if(%client.isModerator || %client.isAdmin)
		{
			%msg = %Chat SPC %Chat2 SPC %Chat3 SPC %Chat4 SPC %Chat5 SPC %Chat6 SPC %Chat7 SPC %Chat8 SPC %Chat9 SPC %Chat10 SPC %Chat11 SPC %Chat12 SPC %Chat13 SPC %Chat14 SPC %Chat15 SPC %Chat16 SPC %Chat17 SPC %Chat18 SPC %Chat19 SPC %Chat20;
			%msg = trim(%msg);

			%count = ClientGroup.getCount();
			for(%cl = 0; %cl < %count; %cl++)
			{
				%clientB = ClientGroup.getObject(%cl);
				if(%clientB.isAdmin || %clientB.isModerator)
					messageClient(%clientB, '', "\c5ModChat\c6(\c4" @ %client.name @ "\c6): " @ %msg);
			}
			echo("ModChat (" @ %client.name @ "): " @ %msg);
		}

		else
			messageclient(%client, '', "\c6You are not an Moderator!");
	}
};
activatePackage(ModeratorCMDS);