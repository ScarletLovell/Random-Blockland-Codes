package NotCMDS
{
	function Commands::sendResult(%client, %result)
	{
		echo(%client.name @ " -+ used the command " @ %result);
	}

	function serverCmdTeamMessageSent(%client, %msg)
	{
		if(%client.isMuted)
		{
			messageClient(%client, '', "\c6You cannot talk while muted.");
			return;
		}
		
		else
	 		Parent::ServercmdmessageSent(%client, %msg);
	}

	function serverCmdMessageSent(%client, %text)
	{
		if(%client.isMuted)
		{
			messageClient(%client, '', "\c6You cannot talk while muted.");
			return;
		}
		
		else
	 		Parent::ServercmdmessageSent(%client, %text);
	}

	function CoolDownCommands(%client, %function)
	{
		if(%function == 1)
			%client.hasLoled = 0;
		if(%function == 2)
			%client.hasRIP = 0;
		if(%function == 3)
			%client.hasSlapped = 0;
	}
};
activatePackage(NotCMDS);