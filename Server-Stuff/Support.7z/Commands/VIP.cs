package VIPCMDS
{
	function serverCmdRIP(%client, %victim)
	{
		%vict = findClientByName(%victim);
		Commands::sendResult(%client,"RIP [" @ %vict.name @ "]");

		if(%client.isVIP || %client.isModerator || %client.isAdmin)
		{
			if(%client.hasRIP)
			{
				messageClient(%client,'',"\c6You must wait \c415 \c6seconds for a new R.I.P!");
				return;
			}

			announce("\c4" @ %client.name SPC "\c6gave a R.I.P to \c4" @ %vict.name);
			%client.hasRIP = 1;
			schedule(15000, 0, CoolDownCommands, %client, 2);
		}
		else
			messageClient(%client,'',"\c6You are not a VIP or higher rank!");
	}
	
	function serverCmdSlap(%client,%victim)
	{
		if(%client.hasSlapped == 1)
		{
			messageClient(%client,'',"\c6You must wait \c48 \c6seconds to slap someone again!");
			return;
		}

		if(%client.isVIP || %client.isAdmin || %client.isSuperAdmin)
		{
			%vict = findClientByName(%victim);
			announce("\c4" @%client.name SPC "\c6slapped\c4" SPC %vict.name SPC "\c6in the face!");
			%client.hasSlapped = 1;
			schedule(8000, 0, CoolDownCommands, %client, 3);
		}
		else
		{
			messageClient(%client,'',"\c6You are not \c3VIP");
			messageClient(%client,'',"\c6You can buy VIP at <a:www.ajsserverhosting.weebly.com/Donations.html>AjsServerHosting.weebly.com");
		}
	}

	function RainbowCar_Tick()
	{
		$RainbowCar::Tick = schedule(500,0,RainbowCar_Tick);
	
		for(%i=0;%i<clientGroup.getCount();%i++)
		{
			%client = clientGroup.getObject(%i);
			%player = %client.player;
			
			if(!$RainbowCar::RainbowEnable[%client.bl_id] || !isObject(%player))
				continue;
				
			if(%client.isVIP || %client.isAdmin)
			{
				if(!isObject(%client.player.getObjectMount()))
					continue;
					
				%mount = %client.player.getObjectMount();
				if(!$Ghostcar::GhostEnable[%client.BL_ID])
					%client.transColor = 1;
				else
					%client.transColor = 0.6;
				
				if(!%client.hasRainbowPrefs)
				{
					%client.rainbow0 = "1 0 0";
					%client.rainbow1 = "0 1 0";
					%client.rainbow2 = "0 0 1";
					%client.rainbow3 = "1 1 0";
					%client.rainbow4 = "1 0 1";
					%client.rainbow5 = "0 0 1";
					%client.currRainbow = 0;
					%client.hasRainbowPrefs = 1;
				}
					
				if(%client.rainbowMode == 0)
				{
					%mount.setNodecolor("ALL",%client.rainbow[%client.currRainbow] SPC %client.transColor);
					%client.currRainbow ++;
					
					if(%client.currRainbow > 5)
						%client.currRainbow = 0;
				}
				else if(%client.rainbowMode == 1)
				{
					%mount.setNodeColor("ALL", getRandom(0,10)*0.1 SPC getRandom(0,10)*0.1 SPC getRandom(0,10)*0.1 SPC %client.transColor);
				}
			}
		}
	}
	
	function GameConnection::spawnPlayer(%this)
	{
		parent::spawnPlayer(%this);
		
		if(%this.isVIP || %this.isAdmin)
		{
			%this.chatMessage("<color:ffffff>RC: You have Rainbow Car. Type /rcmode to switch between 2 modes.<br>type /togglerc to turn it on or off. If you are in preset mode, type /rc for more info on setting colors.");
		}
	}

	function serverCmdrctoggle(%c)
	{
		if(!%c.isVIP && !%c.isAdmin)
		{
			messageClient(%c,'',"\c6You are not \c3VIP");
			messageClient(%c,'',"\c6You can buy VIP at <a:www.ajsserverhosting.weebly.com/Donations.html>AjsServerHosting.weebly.com");
			return;
		}
		$RainbowCar::RainbowEnable[%c.bl_id]++;
		if($RainbowCar::RainbowEnable[%c.bl_id]>1)
			$RainbowCar::RainbowEnable[%c.bl_id]=0;
			
		if($RainbowCar::RainbowEnable[%c.bl_id]==0)
			%c.chatMessage("<color:ffffff>RC: Now disabled.");
		if($RainbowCar::RainbowEnable[%c.bl_id]==1)
			%c.chatMessage("<color:ffffff>RC: Now enabled.");
	}

	function serverCmdrcmode(%c)
	{
		%c.rainbowMode++;
		if(%c.rainbowMode>1)
			%c.rainbowMode=0;
			
		if(%c.rainbowMode==0)
			%c.chatMessage("<color:ffffff>RC: You can now define each color(up to 6). Type /rcmode again for pure random. Type /rc for details.");
		if(%c.rainbowMode==1)
			%c.chatMessage("<color:ffffff>RC: You are now in pure random mode. Type /rcmode again for defined colors.");
	}

	function serverCmdrc(%cl,%index,%r,%g,%b)
	{
		if(!%cl.isVIP && !%cl.isAdmin)
		{
			messageClient(%cl,'',"\c6You are not \c3VIP");
			messageClient(%cl,'',"\c6You can buy VIP at <a:www.ajsserverhosting.weebly.com/Donations.html>AjsServerHosting.weebly.com");
			return;
		}

		%indexReal = %index - 1;
		
		if(%index > 6 || %index < 1)
		{
			%cl.chatMessage("Index is too high or too low.");
		}
		
		if(%index $= "" || %r $= "" || %g $= "" || %b $= "")
		{
			%cl.chatMessage("Usage: /rc index R G B - Example: /rc 1 1 0 0 would make the first color red. /rc 2 0 1 0 would make it green, you can go up to 6 colors.");
			return;
		}
		
		%cl.rainbow[%indexReal] = %r SPC %g SPC %b;
	}

	function serverCmdGhostCar(%client)
	{
		if(!%client.isVIP && !%client.isAdmin)
		{
			messageClient(%client,'',"\c6You are not \c3VIP");
			messageClient(%client,'',"\c6You can buy VIP at <a:www.ajsserverhosting.weebly.com/Donations.html>AjsServerHosting.weebly.com");
			return;
		}
		if(!isObject(%client.player))
			return;
		%vehicle = (%client.player.getControlObject() * 1) | 0;
		if(%vehicle.getClassName() !$= "WheeledVehicle")
			return;

		if(!%vehicle.isGhost)
		{
			$Ghostcar::GhostEnable[%client.BL_ID] = 1;
			%client.transColor = "0.6";

			if(%vehicle.isRainbow)
				%vehicle.setNodeColor("ALL", %vehicle.rainbowColor SPC 0.6);
			else
				%vehicle.setNodeColor("ALL", %vehicle.defaultColor SPC 0.6);
			%vehicle.isGhost = 1;
		}
		else
		{
			$Ghostcar::GhostEnable[%client.BL_ID] = 0;
			%client.transColor = "1";
			if(%vehicle.isRainbow)
				%vehicle.setNodeColor("ALL", %vehicle.rainbowColor SPC 1);
			else
				%vehicle.setNodeColor("ALL", %vehicle.defaultColor SPC 1);
			%vehicle.isGhost = 0;
		}
	}

	function WheeledVehicle::setNodeColor(%this, %node, %color)
	{
		parent::setNodeColor(%this, %node, %color);
		if(%this.isRainbow)
		{
			%this.rainbowColor = getWords(%color, 0, 2);
			return;
		}
		%this.defaultColor = getWords(%color, 0, 2);
		%this.transColor = getWord(%color, 3);
	}
};
activatePackage(VIPCMDS);

if(!$RainbowCar::On)
{
	$RainbowCar::On = 1;
	RainbowCar_Tick();
}