package MemberCMDS
{
	function serverCmdChangeTeam(%client,%victim,%teamName)
	{
		%vict = findClientByName(%victim);
		Commands::sendResult(%client,"changeTeam [" @ vict.name SPC "---" SPC %teamName @ "]");

		if(!isObject(%vict))
		{
			messageClient(%client,'',"\c4" @ %victim @ " \c6is not a valid player.");
			return;
		}

		if(%client.isMember || %client.isVIP || %client.isAdmin || %client.isSuperAdmin || %client.isCoHost || %client.isModerator)
		{
			if(%teamName !$= "CoRK" && %teamName !$= "Red" && %teamName !$= "Yellow" && %teamName !$= "Green" && %teamName !$= "Blue")
			{
				messageClient(%client,'',"\c4" @ %teamName @ " \c6is not a valid team.");
				return;
			}

			if(%teamName $= "Red")
				%vict.joinTeam("Red");

			if(%teamName $= "Blue")
				%vict.joinTeam("Blue");

			if(%teamName $= "CoRK")
				%vict.joinTeam("CoRK");

			if(%teamName $= "Yellow")
				%vict.joinTeam("Yellow");

			if(%teamName $= "Green")
				%vict.joinTeam("Green");

			announce("\c4"@%client.name@" \c6put \c4"@%vict.name@" \c6on the team: \c4"@%teamName);
			echo(%client.name @ " changed to the team " @ %teamName);
		}
		else
		{
			messageClient(%client,'',"\c6You are not a Member or Above!");
		}
	}
	
}