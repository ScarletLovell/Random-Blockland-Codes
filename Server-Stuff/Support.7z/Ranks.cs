//By Anthonyrules144 and Eahle517
package Ranks
{
	function serverCmdMakeRank(%client, %victim, %rank)
	{
		%vict = findClientByName(%victim);

		if(%client.isSuperAdmin) 
		{

			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4"@ %victim @" \c6is not a valid player.");
				return;
			}

			if(%rank !$= "CoHost" && %rank !$= "Respected" && %rank !$= "VIP" && %rank !$= "Member" && %rank !$= "Moderator")
			{
				messageClient(%client,'',"\c4" @%rank SPC "\c6is not a rank.");
				return;
			}

			if(%rank $= "CoHost" && %client.BL_ID == getNumKeyID())
			{
				if(%vict.isCoHost)
				{
					messageClient(%client,'',"\c6That person is already CoHost!");
					return;
				}

				if($Pref::Server::AutoCoHostList !$= "")
					messageClient(%client,'',"\c6The CoHost is already: " @ getWords($Pref::Server::AutoCoHostList, 1, getWordCount($Pref::Server::AutoCoHostList)));

				else
				{
					%vict.isCoHost = 1;
					announce("\c4"@ %vict.name @" \c6has become \c0Co-Host \c6(Auto)");

					$Pref::Server::AutoCoHostList = addItemToList($Pref::Server::AutoCoHostList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}
			if(%rank $= "Moderator")
			{
				if(%vict.isMod)
				{
					messageClient(%client,'',"\c6That person is already Moderator!");
					return;
				}

				else
				{
					%vict.isVIP=1;
					announce("\c4"@ %vict.name @" \c6has become a \c5Moderator \c6(Auto)");
					$Pref::Server::AutoModList = addItemToList($Pref::Server::AutoModList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}
					
			if(%rank $= "Respected")
			{
				if(%vict.isRespected)
				{
					messageClient(%client,'',"\c6That person is already Respected!");
					return;
				}

				else
				{
					%vict.isRespected=1;
					announce("\c4"@ %vict.name @" \c6has become  \c5Respected \c6(Auto)");
					$Pref::Server::AutoRespectedList = addItemToList($Pref::Server::AutoRespectedList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}

			if(%rank $= "Member")
			{
				if(%vict.isMember)
				{
					messageClient(%client,'',"\c6That person is already Member!");
					return;
				}

				else
				{
					%vict.isMember=1;
					announce("\c4"@ %vict.name @" \c6has become a \c5Member\c6(Auto)");
					$Pref::Server::AutoMemberList = addItemToList($Pref::Server::AutoMemberList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}

			if(%rank $= "VIP")
			{
				if(%vict.isVIP)
				{
					messageClient(%client,'',"\c6That person is already VIP!");
					return;
				}

				else
				{
					%vict.isVIP=1;
					announce("\c4"@ %vict.name @" \c6has become a \c3VIP \c6(Auto)");
					$Pref::Server::AutoVIPList = addItemToList($Pref::Server::AutoVIPList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}
		}
		else
			messageClient(%client,'',"\c6You are not a Super Admin!");
	}

	function serverCmdUnRank(%client,%victim,%rank)
	{
		%vict = findClientByName(%victim);

		if(%client.isSuperAdmin)
		{
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4"@%victim@" \c6is not a valid player.");
				return;
			}

			if(%rank !$= "CoHost" && %rank !$= "Respected" && %rank !$= "VIP" && %rank !$= "Member")
			{
				messageClient(%client,'',"\c4" @ %rank SPC "\c6is not a rank.");
				return;
			}
				
			if(%rank $= "CoHost" && %client.BL_ID == getNumKeyID())
			{
				if(%vict.isCoHost)
				{
					%vict.isCoHost=0;
					announce("\c6"@ %vict.name @ " \c4has been removed from \c1CoHost \c4(Auto)");
					$Pref::Server::AutoCoHostList = removeItemFromList($Pref::Server::AutoCoHostList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}

			if(%rank $= "Respected")
			{
				if(%vict.isRespected)
				{
					%vict.isRespected=0;
					announce("\c6"@ %vict.name @ " \c4has been removed from \c5Respected \c4(Auto)");
					$Pref::Server::AutoRespectedList = removeItemFromList($Pref::Server::AutoRespectedList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}

			if(%rank $= "Member")
			{
				if(%vict.isMember)
				{
					%vict.isMember=0;
					announce("\c6"@ %vict.name @ " \c4has been removed from \c6Member \c4(Auto)");
					$Pref::Server::AutoMemberList = removeItemFromList($Pref::Server::AutoMemberList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}

			if(%rank $= "VIP")
			{
				if(%vict.isVIP)
				{
					%vict.isVIP=0;
					announce("\c6"@ %vict.name @ " \c4has been removed from \c3VIP \c4(Auto)");
					$Pref::Server::AutoVIPList = removeItemFromList($Pref::Server::AutoVIPList,%vict.bl_id);
					export("$Pref::Server::*","config/server/prefs.cs");
				}
			}
		}
		else
			messageClient(%client,'',"\c6You are not a Super Admin!");
	}
};
activatePackage(Ranks);
