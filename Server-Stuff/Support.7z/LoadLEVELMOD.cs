exec("./Levelmod/Levelmod.cs");
exec("./Levelmod/Saving.cs");
exec("./Levelmod/Text.cs");