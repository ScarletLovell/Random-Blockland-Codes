//./Main/Log.cs
//Will log every command that adminstration, mods, and VIPs do every hour
 
package LogFile
{
	function LogFile(%type, %client, %victim, %time, %reason)
	{
		if(%type !$= "Ban" && %type !$= "Kick" && %type !$= "Startup" && %type !$= "Shutdown")
			return;
		
		%time = ConvertTimeToUS();
		%date = getDate();

		%file = new FileObject();
		if(%type $= "Ban")
		{
			%file.openForAppend("config/server/Log/Bans.txt");
			%file.writeLine(%date SPC %time TAB %client.name SPC %client.BL_ID TAB %victim.name SPC %victim.BL_ID TAB %reason TAB %time);
		}
		else if(%type $= "Kick")
		{
			%file.openForAppend("config/server/Log/Kicks.txt");
			%file.writeLine(%date SPC %time TAB %client.name SPC %client.BL_ID TAB %victim.name SPC %victim.BL_ID);
		}
		else if(%type $= "Startup")
		{
			%file.openForAppend("config/server/Log/Startups.txt");
			%file.writeLine(%date SPC %time);
		}
		else if(%type $= "Shutdown")
		{
			%file.openForAppend("config/server/Log/Shutdowns.txt");
			%file.writeLine(%date SPC %time);
		}
		
		%file.close();
		%file.delete();
	}

	function serverCmdKick(%client, %target)
	{
		parent::serverCmdKick(%client, %target);
		
		%target = findClientByName(%target);
		if(isObject(%target))
			LogFile("Kick", %client, %target);
	}
	
	function serverCmdBan(%client, %target, %targetBL_ID, %time, %reason)
	{
		parent::serverCmdBan(%client, %target, %targetBL_ID, %time, %reason);
		%target = findClientByName(%target);
		if(isObject(%target))
			LogFile("Ban", %client, %target, %time, %reason);
	}

	function onServerCreated()
	{
		LogFile("Startup");
		parent::onServerCreated();
	}

	function onServerDestroyed()
	{
		LogFile("Shutdown");
		parent::onServerDestroyed();
	}

	function ConvertTimeToUS()
	{
		%time = strReplace(getWord(getDateTime(), 1), ":", " ");//Fixed u shud exec it
		%time = getWords(%time, 0, 2);
		
		if(getWord(%time, 0) > 12)
		{
			%hour = getWord(%time, 0) - 12;
			%time = %hour SPC getWords(%time, 1, 2) @ "PM";
		}
		else
			%time = %time @ "AM";

		%time = strReplace(%time, " ", ":");
		return %time;
	}

	function getDate()
	{
		return getWord(getDateTime(), 0);
	}
};
activatePackage(LogFile);
