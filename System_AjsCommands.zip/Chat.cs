package NewChat
{
	function checkLetter(%letter)
	{
		%charList = "!@#$%^&*()_+1234567890-=[]{}\\|;':\",.<>/? ";
		for(%i = 0; %i < strLen(%charList); %i++)
		{
			if(%letter $= getSubStr(%charList, %i, 1))
					return 1;
		}
		return 0;
	}
	
	function serverCmdMessageSent(%client, %msg)
	{
		if(getSubStr(%msg,0,1) $= "$")
		{
			parent::serverCmdMessageSent(%client,%msg);
			return;
		}
		%msg = stripMLControlChars(%msg);
		%msg = trim(%msg);
		
		if(strPos(%msg, "http://") >= 0 && !%client.isAdmin)
		{
			for(%i = 0; %i < getWordCount(%msg); %i++)
			{
				%word = getWord(%msg, %i);
				if(strPos(%word, "http://") >= 0)
				{
					%msg = strReplace(%msg, %word, "[Link Removed]");
				}
			}
		}
		
		if(strPos(strUpr(%msg), %msg) >= 0 && strLen(%msg) >= 5)
				%msg = strLwr(%msg);
		
		for(%i = 0; %i < strLen(%msg); %i++)
		{
			%letter = getSubStr(%msg, %i, 1);
			if(strPos(strUpr(%letter), %letter) >= 0 && !checkLetter(%letter))
			{
					%capitalLetters++;
					if(%position - %pos >= 5)
							%capitalLetters = 0;
					%pos = %position;
			}
			
			%position++;
			
			if(%capitalLetters >= 10)
			{
				%decapitalizeMessage = 1;
				break;
			}
		}
		
		if(%decapitalizeMessage)
			%msg = strLwr(%msg);
		
		parent::serverCmdMessageSent(%client, %msg);
	}
};
activatePackage(NewChat);
