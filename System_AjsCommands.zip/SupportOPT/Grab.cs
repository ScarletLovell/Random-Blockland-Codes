//MQData (Database)
//by Wrapperup
//Use for anything to hold data, to store for later or when server resets.

//Prefs
	$Pref::Server::MQData::autoLoad = 1;
	$Pref::Server::MQData::Debug = 0;

function MQ_e(%msg,%trace)
{
	if($Pref::Server::MQData::Debug)
	{
		if(%trace $= "")
			%trace = "NULL";
		if(%msg !$= "")
			error("MQDATA - ERROR:" SPC %msg SPC "| TRACE FNC:" SPC %trace);
	}
}

function MQ_m(%msg)
{
	if($Pref::Server::MQData::Debug)
	{
		if(%msg !$= "")
			echo("MQDATA:" SPC %msg);
	}
}

function GameConnection::DBset(%this,%group,%data) //if %save is true, the data will be saved and exported.
{
	if(!isObject(%this))
	{
		MQ_e("Calling on non existant GameConnection!","GameConnection::DBadd()");
		return;
	}
	MQ_m("ID:" SPC %this.getBLID() SPC "| GROUP:" SPC %group SPC "| DATA:" SPC %data);
	MQData_setDataClient(%this.getBLID(),%group,%data);
}
function GameConnection::DBget(%this,%group)
{
	if(!isObject(%this))
	{
		MQ_e("Calling on non existant GameConnection!","GameConnection::DBget()");
		return;
	}
	%data = $MQData::ClientData[%this.getBLID(),%group];
	return %data;
}

function MQData_setDataClient(%blid,%group,%data)
{
	if(%blid $= "" || %group $= "" || %data $= "")
	{
		MQ_e("Missing Arguments! Arguments: %blid,%group,%data.","MQData_setDataClient()");
		return;
	}
	$MQData::ClientData[%blid,%group] = %data;
	export("$MQData::ClientData*","config/server/MQData/ClientData.cs");
	MQ_m("Client Data saved and exported.");
}

function MQData_setData(%group,%data)
{
	if(%group $= "" || %data $= "")
	{
		MQ_e("Missing Arguments! Arguments: %group,%data.","MQData_setData()");
		return;
	}
	$MQData::ServerData[%group] = %data;
	export("$MQData::ServerData*","config/server/MQData/ServerData.cs");
	MQ_m("GROUP:" SPC %group SPC "| DATA:" SPC %data);
}

function MQData_getData(%group)
{
	if(%group $= "")
	{
		MQ_e("Missing Arguments! Arguments: %group.","MQData_getData()");
		return;
	}
	%data = $MQData::ServerData[%group];
	return %data;
}

function MQData_loadDatabase(%database)
{
	if(%database $= "")
	{
		MQ_m("Loading all databases...");
		%path = "config/server/MQData/";
		%clf = %path @ "ClientData.cs";
		%servf = %path @ "ServerData.cs";
		if(isFile(%clf))
			exec(%clf);
			
		if(isFile(%servf))
			exec(%servf);
	}
	
	if(%database $= "client")
	{
		MQ_m("Loading client database...");
		%path = "config/server/MQData/";
		%clf = %path @ "ClientData.cs";
		if(isFile(%clf))
			exec(%clf);
	}
	
	if(%database $= "server")
	{
		MQ_m("Loading server database...");
		%path = "config/server/MQData/";
		%servf = %path @ "ServerData.cs";
		if(isFile(%servf))
			exec(%servf);
	}
}

function MQData_saveDatabase(%database)
{
	if(%database $= "")
	{
		MQ_m("Saving all databases...");
		%path = "config/server/MQData/";
		%clf = %path @ "ClientData.cs";
		%servf = %path @ "ServerData.cs";
		export("$MQData::ClientData*","config/server/MQData/ClientData.cs");
		export("$MQData::ServerData*","config/server/MQData/ServerData.cs");
	}
	
	if(%database $= "client")
	{
		MQ_m("Saving client database...");
		%path = "config/server/MQData/";
		%clf = %path @ "ClientData.cs";
		export("$MQData::ClientData*","config/server/MQData/ClientData.cs");
	}
	
	if(%database $= "server")
	{
		MQ_m("Saving server database...");
		%path = "config/server/MQData/";
		%servf = %path @ "ServerData.cs";
		export("$MQData::ServerData*","config/server/MQData/ServerData.cs");
	}
}

//initial loadup
if($Pref::Server::MQData::autoLoad)
	MQData_loadDatabase();