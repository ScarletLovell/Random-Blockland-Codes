//./Joined.cs

package Joined
{
	function GameConnection::AutoAdminCheck(%client)
	{
		parent::AutoAdminCheck(%client);
		
		%client.clanOldP = %client.clanPrefix;
		%client.clanOldS = %client.clanSuffix;
		schedule(200, 0, checkRank, %client);
		
		if($LevelMod::isEnabled)
			%client.clanPrefix = %client.otherTag;
	}
};
activatePackage(Joined);

function checkRank(%client)
{
	%list[0] = $Pref::Server::AutoCoHostList;
	%list[1] = $Pref::Server::AutoVIPList;
	%list[2] = $Pref::Server::AutoRespectedList;
	%list[3] = $Pref::Server::AutoMemberList;
	%list[4] = $Pref::Server::AutoModList;
	%listTotal = 4;
	
	for(%i = 0; %i <= %listTotal; %i++)
	{
		if(hasItemOnList(%list[%i], %client.BL_ID))
		{
			if(%i == 0)
			{
				%client.isCoHost = 1;
				%client.isAdmin = 1;
				%client.isSuperAdmin = 1;
				messageAll('MsgAdminForce', '\c6%1 \c4has become \c0Co-Host \c4(Auto)', %client.name);
			}
			if(%i == 1)
			{
				%client.isVIP = 1;
				messageAll('MsgAdminForce', '\c6%1 \c4has become \c3VIP \c4(Auto)', %client.name);
			}
			if(%i == 2)
			{
				%client.isRespected = 1;
				messageAll('MsgAdminForce', '\c6%1 \c4has become \c1Respected \c4(Auto)', %client.name);
			}
			if(%i == 3)
			{
				%client.isMember = 1;
				messageAll('MsgAdminForce', '\c6%1 \c4has become \c6Member \c4(Auto)', %client.name);
			}
			if(%i == 4)
			{
				%client.isModerator = 1;
				messageAll('MsgAdminForce', '\c6%1 \c4has become \c5Moderator \c4(Auto)', %client.name);
			}
		}
	}
}
