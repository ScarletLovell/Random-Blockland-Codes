//./Roatate MSG
//10 minutes = 600000 Milliseconds
//5 minutes = 300000 Milliseconds <-- Chosen

function registerMessageRotationInfo(%number)
{
	if(%number $= "")
		%number = 10;
	for(%i = 1; %i <= %number; %i++)
	{
		RTB_registerPref("Info " @ %i, "Message Rotation", "$Pref::Server::MessageRotation" @ %i, "string 300", "System_AjsCommands", "Server Info " @ %i, 0, 0);
	}
}

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
  		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	 
	RTB_registerPref("Title Font", "Message Rotation", "$Pref::Server::MessageRotationTitleFont", "string 200", "System_AjsCommands", "Arial", 0, 0);
	RTB_registerPref("Title Size", "Message Rotation", "$Pref::Server::MessageRotationTitleSize", "int 1 50", "System_AjsCommands", "24", 0, 0);
	RTB_registerPref("Info Font", "Message Rotation", "$Pref::Server::MessageRotationInfoFont", "string 200", "System_AjsCommands", "Arial", 0, 0);
	RTB_registerPref("Info Size", "Message Rotation", "$Pref::Server::MessageRotationInfoSize", "int 1 50", "System_AjsCommands", "20", 0, 0);

	RTB_registerPref("Title", "Message Rotation", "$Pref::Server::MessageRotationTitle", "string 50", "System_AjsCommands", "Server Info:", 0, 0);
	registerMessageRotationInfo($Pref::Server::MessageRotationInfoNumber);

	RTB_registerPref("Number of Infos", "Message Rotation", "$Pref::Server::MessageRotationInfoNumber", "int 0 50", "System_AjsCommands", "10", 1, 0);
	RTB_registerPref("Time Between Infos", "Message Rotation", "$Pref::Server::MessageRotationInfoTime", "int 10 999", "System_AjsCommands", "60", 0, 0);
}

function RotateMSG_tick(%i)
{
	cancel($RotateMSG::tick);
	if(%i $= "" || %i > $Pref::Server::MessageRotationInfoNumber)
		%i = 0;

	%msg = $Pref::Server::MessageRotation[%i];
	if(%msg $= "")
	{
		$RotateMSG::Schedule = schedule($Pref::Server::MessageRotationInfoTime * 1000, 0, RotateMSG_tick, %i++);
		return;
	}

	%titleFont = "<font:" @ $Pref::Server::MessageRotationTitleFont @ ":" @ $Pref::Server::MessageRotationTitleSize @ ">";
	%infoFont = "<font:" @ $Pref::Server::MessageRotationInfoFont @ ":" @ $Pref::Server::MessageRotationInfoSize @ ">";

	announce(%titleFont @ "\c7" @ $Pref::Server::MessageRotationTitle SPC %infoFont @ "\c6" @ %msg);
	cancel($RotateMSG::Schedule);
	$RotateMSG::Schedule = schedule($Pref::Server::MessageRotationInfoTime * 1000, 0, RotateMSG_tick, %i++);
}

if(!isEventPending($RotateMSG::tick))
	RotateMSG_tick(0);
