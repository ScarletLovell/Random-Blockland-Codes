datablock ProjectileData(PlungerProjectile)
{
	directDamage			= 30;
	directDamageType		= $DamageType::butterflyknifeDirect;
	explosion				= swordExplosion;

	muzzleVelocity			= 104;
	velInheritFactor		= 1;

	armingDelay				= 0;
	lifetime				= 75;
	fadeDelay				= 70;
	bounceElasticity		= 0;
	bounceFriction			= 0;
	isBallistic				= false;
	gravityMod				= 0.0;

	hasLight				= false;
	lightRadius				= 3.0;
	lightColor				= "0 0 0.5";
};

datablock ProjectileData(PlungerKillProjectile)
{
	backstab				= 180;
	directDamage			= 103;
	directDamageType		= $DamageType::butterflyknifeDirect;
	explosion				= swordExplosion;

	muzzleVelocity			= 115;
	velInheritFactor		= 1;

	armingDelay				= 0;
	lifetime				= 95;
	fadeDelay				= 70;
	bounceElasticity		= 0;
	bounceFriction			= 0;
	isBallistic				= false;
	gravityMod				= 0.0;

	hasLight				= false;
	lightRadius				= 3.0;
	lightColor				= "0 0 0.5";
};

//////////
// item //
//////////

datablock ItemData(PlungerItem)
{
	category		= "Weapon";
	className		= "Weapon";

	shapeFile		= "./Plunger.dts";
	mass			= 1;
	density			= 0.2;
	elasticity		= 0.2;
	friction		= 0.6;
	emap			= true;

	uiName			= "Plunger";
	iconName		= "";
	doColorShift	= false;
	colorShiftColor	= "0.500 0.500 0.500 1.000";

	image			= PlungerImage;
	canDrop			= true;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(PlungerImage)
{
	shapeFile				= "./Plunger.dts";
	emap					= true;

	mountPoint				= 0;
	offset					= "0 0 -0.5";

	correctMuzzleVector		= true;

	className				= "WeaponImage";

	item					= PlungerItem;
	ammo					= " ";
	projectile				= PlungerProjectile;
	projectileType			= Projectile;

	melee					= false;
	armReady				= true;

	doColorShift			= false;
	colorShiftColor			= "0.500 0.500 0.500 1.000";

	stateName[0]					= "Activate";
	stateTimeoutValue[0]			= 0.5;
	stateTransitionOnTimeout[0]		= "Ready";
	stateSequence[0]				= "activate";
	stateSound[0]					= ButterflyknifeactivateSound;

	stateName[1]					= "Ready";
	stateSequence[1]				= "ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateAllowImageChange[1]		= true;

	stateName[2]					= "Charge";
	stateTransitionOnTimeout[2]		= "Armed";
	stateTimeoutValue[2]			= 0.7;
	stateScript[2]					= "onCharge";
	stateSequence[2]				= "ready";
	stateWaitForTimeout[2]			= false;
	stateTransitionOnTriggerUp[2]	= "AbortChargefire";
	stateAllowImageChange[2]		= false;

	stateName[3]					= "AbortChargefire";
	stateTransitionOnTimeout[3]		= "stopFire";
	stateTimeoutValue[3]			= 0.2;
	stateFire[3]					= true;
	stateSequence[3]				= "ready";
	stateScript[3]					= "onFiretwo";
	stateWaitForTimeout[3]			= true;
	stateAllowImageChange[3]		= true;
	stateSound[3]					= ButterflyknifeFireSound;

	stateName[4]					= "StopFire";
	stateTransitionOnTimeout[4]		= "Ready";
	stateTimeoutValue[4]			= 0.2;
	stateAllowImageChange[4]		= false;
	stateWaitForTimeout[4]			= true;

	stateScript[4]					= "onStopFire";
	stateName[5]					= "Armed";
	stateTransitionOnTriggerUp[5]	= "Fire";
	stateAllowImageChange[5]		= false;

	stateName[6]					= "Fire";
	stateTransitionOnTimeout[6]		= "Ready";
	stateTimeoutValue[6]			= 0.2;
	stateFire[6]					= true;
	stateSequence[6]				= "ready";
	stateScript[6]					= "onFire";
	stateWaitForTimeout[6]			= true;
	stateAllowImageChange[6]		= false;
	stateSound[6]					= ButterflyknifeFireSound;
};

function PlungerImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, spearReady);
}

function PlungerImage::onStopFire(%this, %obj, %slot)
{
	%obj.playthread(2, root);
}

function PlungerImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, spearThrow);
	%projectile = PlungerKillProjectile;
	%spread = 0.00001;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function PlungerImage::onFiretwo(%this,%obj,%slot)
{
	%projectile = PlungerProjectile;
	%spread = 0.00001;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}