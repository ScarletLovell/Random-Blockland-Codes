datablock ParticleData(ElectricCKnifeAmbient)
{
	dragCoefficient      = 0;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0;
	constantAcceleration = 0;
	spinRandomMin        = -300;
	spinRandomMax        = 300;
	lifetimeMS           = 750;
	lifetimeVarianceMS   = 250;
	textureName          = "Add-ons/Projectile_Radio_Wave/bolt.png";
	colors[0]            = "1 1 0 0";
	colors[1]            = "1 1 1 1";
	colors[2]            = "1 1 0 0.5";
	colors[3]            = "1 1 0 0";
	sizes[0]             = 0.1;
	sizes[1]             = 0.5;
	sizes[2]             = 0.7;
	sizes[3]             = 0.2;
	times[0]             = 0;
	times[1]             = 0.4;
	times[2]             = 0.8;
	times[3]             = 1;
};

datablock ParticleEmitterData(ElectricCKnifeAmbientEmitter)
{
	ejectionPeriodMS = 200;
	periodVarianceMS = 100;
	ejectionVelocity = 0.1;
	velocityVariance = 0;
	ejectionOffset   = -0.5;
	thetaMin         = 5;
	thetaMax         = 25;
	phiReferenceVel  = 0;
	phiVariance      = 360;
	overrideAdvance  = false;
	particles        = "ElectricCKnifeAmbient";

	uiName = "ElectricCKnife Ambient";
};

datablock ParticleData(ElectricCKnifeExplosionParticle)
{
   dragCoefficient      = 3;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0;
   constantAcceleration = 0;
   spinRandomMin	= -500;
   spinRandomMax	= 500;
   lifetimeMS           = 1500;
   lifetimeVarianceMS   = 500;
   textureName          = "./ban.png";
   colors[0]		= "1 1 1 1";
   colors[1]		= "1 0 0 0";
   sizes[0]		= 2;
   sizes[1]		= 0.5;
};

datablock ProjectileData(ChefKnifeElectricProjectile)
{
	directDamage			= 30;
	directDamageType		= $DamageType::butterflyknifeDirect;
	explosion				= swordExplosion;

	muzzleVelocity			= 104;
	velInheritFactor		= 1;

	armingDelay				= 0;
	lifetime				= 75;
	fadeDelay				= 70;
	bounceElasticity		= 0;
	bounceFriction			= 0;
	isBallistic				= false;
	gravityMod				= 0.0;

	hasLight				= false;
	lightRadius				= 3.0;
	lightColor				= "0 0 0.5";
};

datablock ProjectileData(ChefKnifeElectricKillProjectile)
{
	backstab				= 180;
	directDamage			= 103;
	directDamageType		= $DamageType::butterflyknifeDirect;
	explosion				= swordExplosion;

	muzzleVelocity			= 115;
	velInheritFactor		= 1;

	armingDelay				= 0;
	lifetime				= 95;
	fadeDelay				= 70;
	bounceElasticity		= 0;
	bounceFriction			= 0;
	isBallistic				= false;
	gravityMod				= 0.0;

	hasLight				= false;
	lightRadius				= 3.0;
	lightColor				= "0 0 0.5";
};

//////////
// item //
//////////

datablock ItemData(ChefKnifeElectricItem)
{
	category		= "Weapon";
	className		= "Weapon";

	shapeFile		= "./ChefKnifeElectric.dts";
	mass			= 1;
	density			= 0.2;
	elasticity		= 0.2;
	friction		= 0.6;
	emap			= true;

	uiName			= "ChefKnifeElectric";
	iconName		= "";
	doColorShift	= false;
	colorShiftColor	= "0.500 0.500 0.500 1.000";

	image			= ChefKnifeElectricImage;
	canDrop			= true;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(ChefKnifeElectricImage)
{
	shapeFile				= "./ChefKnifeElectric.dts";
	emap					= true;

	mountPoint				= 0;
	offset					= "0 0 -0.5";

	correctMuzzleVector		= true;

	className				= "WeaponImage";

	item					= ChefKnifeElectricItem;
	ammo					= " ";
	projectile				= ChefKnifeElectricProjectile;
	projectileType			= Projectile;

	melee					= false;
	armReady				= true;

	doColorShift			= false;
	colorShiftColor			= "0.500 0.500 0.500 1.000";

	stateName[0]					= "Activate";
	stateTimeoutValue[0]			= 0.5;
	stateTransitionOnTimeout[0]		= "Ready";
	stateSequence[0]				= "activate";
	stateSound[0]					= ButterflyknifeactivateSound;
	stateEmitter[0]					= ElectricCKnifeAmbientEmitter;
	stateEmitterTime[0]				= 10000;

	stateName[1]					= "Ready";
	stateSequence[1]				= "ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateAllowImageChange[1]		= true;
	stateEmitter[1]					= ElectricCKnifeAmbientEmitter;
	stateEmitterTime[1]				= 10000;
	
	stateName[2]					= "Charge";
	stateTransitionOnTimeout[2]		= "Armed";
	stateTimeoutValue[2]			= 0.7;
	stateScript[2]					= "onCharge";
	stateSequence[2]				= "ready";
	stateWaitForTimeout[2]			= false;
	stateTransitionOnTriggerUp[2]	= "AbortChargefire";
	stateAllowImageChange[2]		= false;
	stateEmitter[2]					= ElectricCKnifeAmbientEmitter;
	stateEmitterTime[2]				= 10000;

	stateName[3]					= "AbortChargefire";
	stateTransitionOnTimeout[3]		= "stopFire";
	stateTimeoutValue[3]			= 0.2;
	stateFire[3]					= true;
	stateSequence[3]				= "ready";
	stateScript[3]					= "onFiretwo";
	stateWaitForTimeout[3]			= true;
	stateAllowImageChange[3]		= true;
	stateSound[3]					= ButterflyknifeFireSound;
	stateEmitter[3]					= ElectricCKnifeAmbientEmitter;
	stateEmitterTime[3]				= 10000;

	stateName[4]					= "StopFire";
	stateTransitionOnTimeout[4]		= "Ready";
	stateTimeoutValue[4]			= 0.2;
	stateAllowImageChange[4]		= false;
	stateWaitForTimeout[4]			= true;
	stateEmitter[4]					= ElectricCKnifeAmbientEmitter;
	stateEmitterTime[4]				= 10000;

	stateScript[4]					= "onStopFire";
	stateName[5]					= "Armed";
	stateTransitionOnTriggerUp[5]	= "Fire";
	stateAllowImageChange[5]		= false;
	stateEmitter[5]					= ElectricCKnifeAmbientEmitter;
	stateEmitterTime[5]				= 10000;

	stateName[6]					= "Fire";
	stateTransitionOnTimeout[6]		= "Ready";
	stateTimeoutValue[6]			= 0.2;
	stateFire[6]					= true;
	stateSequence[6]				= "ready";
	stateScript[6]					= "onFire";
	stateWaitForTimeout[6]			= true;
	stateAllowImageChange[6]		= false;
	stateSound[6]					= ButterflyknifeFireSound;
	stateEmitter[6]					= ElectricCKnifeAmbientEmitter;
	stateEmitterTime[6]				= 10000;
};

function ChefKnifeElectricImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, spearReady);
}

function ChefKnifeElectricImage::onStopFire(%this, %obj, %slot)
{
	%obj.playthread(2, root);
}

function ChefKnifeElectricImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, spearThrow);
	%projectile = ChefKnifeElectricKillProjectile;
	%spread = 0.00001;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function ChefKnifeElectricImage::onFiretwo(%this,%obj,%slot)
{
	%projectile = ChefKnifeElectricProjectile;
	%spread = 0.00001;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}