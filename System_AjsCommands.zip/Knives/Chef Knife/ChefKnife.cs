exec("./Electric/server.cs");
exec("./Glowing/server.cs");
exec("./Normal/server.cs");