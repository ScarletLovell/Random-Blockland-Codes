$KnifeAPI = 1;

$Knife[1] = "Butterfly Knife";
$Knife[2] = "Skewer";
$Knife[3] = "Plunger";
$Knife[4] = "Chef Knife";
$Knife[5] = "Longsword";
$Knife[6] = "Xeno Blade";
$Knife[7] = "Twilight Knife";
$Knife[8] = "Gold Knife";
$Knife[9] = "ChefKnifeElectric";
$Knife[10] = "ChefKnifeGlowing";

$KnifeTotal = 10;

$Knife["VIP"] = "Demon Knife";

function serverCmdKnife(%client, %number)
{
	if(!$Levelmod::isEnabled)
		return;
	if(%client.miniGame <= 0)
			return;
	if(%client.isVIP || %client.isModerator || %client.isAdmin)
		%client.hasVIPKnife = 1;	

	if(%number $= "")
	{
		listKnives(%client);
		return;
	}
	
	if(%number $= "3")
	{
		messageClient(%client,'',"\c6Plunger Knife was removed due to bugs.");
		return;
	}

	if(%number $= "VIP")
	{
		if(!%client.hasVIPKnife)
			return;
		messageClient(%client,'',"\c6Equipped: \c4" @ $Knife["VIP"]);
		%item = strReplace($Knife["VIP"]," ","") @ "Item";
		%client.giveKnife(%item);
		%client.selectedKnife = %number;
		return;
	}
	
	if(%number > $KnifeTotal)
	{
		messageClient(%client,'',"\c6That knife does not exist.");
		return;
	}
	
	if(%number > %client.knifeCount)
	{
		messageClient(%client,'',"\c6You do not have that knife.");
		return;
	}
	
	%knife = $Knife[%number];
	%item = strReplace(%knife," ","") @ "Item";
	if(%knife $= "")
	{
		messageClient(%client,'',"\c6That knife does not exist.");
		return;
	}
	
	%client.selectedKnife = %number;
	messageClient(%client,'',"\c6Equipped: \c4" @ %knife);
	%client.giveKnife(%item);
}

function listKnives(%client)
{
	for(%i = 1; %i <= $KnifeTotal; %i++)
	{
		if(%i > %client.knifeCount)
			break;
		%knife = $Knife[%i];
		if(%i != 3)
			messageClient(%client,'',"\c6[\c4" @ %i @ "\c6] -\c2" SPC %knife);
		else
			messageClient(%client,'',"\c6[\c0" @ %i @ "\c6] -\c2" SPC %knife SPC "\c6- Removed");
	}
	if(%client.hasVIPKnife)
			messageClient(%client,'',"\c6[\c4VIP\c6] -\c2" SPC $Knife["VIP"]);
	messageClient(%client,'',"\c6You may need to scroll up to see these.");
}

package KnifeAPI
{
	function GameConnection::giveKnife(%this, %item)
	{
		if(!$Levelmod::isEnabled)
			return;
		if(!isObject(%this.player))
			return;
		
		%player = %this.player;
		
		%item = (isObject(%item) ? %item.getID() : 0);
		
		%oldTool = %player.tool[0];
		%player.tool[0] = %item;
		
		messageClient(%this,'MsgItemPickup','',0,%item);
		
		if(!isObject(%oldTool))
			%player.weaponCount++;
		
		%image = %item.getID()+1;
		if(%player.getMountedImage(0) != 0)
			%player.mountImage(%image.getName(),0);
	}
	
	function GameConnection::spawnPlayer(%this)
	{
		parent::spawnPlayer(%this);
		if(%this.selectedKnife > 0 || %this.selectedKnife $= "VIP")
			serverCmdKnife(%this, %this.selectedKnife);
		else
			serverCmdKnife(%this, 1);
	}
};
activatePackage(KnifeAPI);
