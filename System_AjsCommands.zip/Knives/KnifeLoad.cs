//Get the knives
exec("./Xeno Blade/server.cs");
exec("./Gold Knife/server.cs");
exec("./Twilight Blade/server.cs");
exec("./Skewer/server.cs");
exec("./Longsword/Longsword.cs");
exec("./Demon Knife/server.cs");
exec("./Chef Knife/ChefKnife.cs");
exec("./Plunger/server.cs");

//Grab knife scripts
exec("./Knives.cs");