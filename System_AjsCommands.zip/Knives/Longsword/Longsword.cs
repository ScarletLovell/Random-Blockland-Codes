exec("./Glowing/server..cs");
exec("./Normal/server.cs");