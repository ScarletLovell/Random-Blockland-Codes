$Levelmod::isEnabled = 1;
package Levelmod
{
	function serverCmdLevel(%client, %target)
	{
		%target = findClientByName(%target);
		messageClient(%client,'',"\c4"@ %target.name @"\c6's level is \c4"@ %target.level SPC "\c6[\c4" @ %target.EXP @ "\c6/\c4" @ %target.maxEXP @ "\c6]");
	}
	
	function serverCmdToggleLevelMod(%client)
	{
		if(%client.isSuperAdmin || %client.isCoHost)
		{
			if($Levelmod::isEnabled)
			{
				announce("\c4" @%client.name@ "\c6has disabled levelmod.");
				$Levelmod::isEnabled = 0;
				for(%i = 0; %i < clientGroup.getCount(); %i++)
				{
					%client = clientGroup.getObject(%i);
				}
			}
			else
			{
				announce("\c4" @ %client.name @ "\c6has enabled levelmod.");
				$Levelmod::isEnabled = 1;
				for(%i = 0; %i < clientGroup.getCount(); %i++)
				{
					%client = clientGroup.getObject(%i);
					loadLevel(%client);
				}
			}
		}
	}
	
	function serverCmdSetLevel(%client,%target,%level)
	{
		if(!$Levelmod::isEnabled)
		{
			messageClient(%client,'',"\c6Levels are disabled!");
			return;
		}
		
		if(!%client.isAdmin)
		{
			messageClient(%client,'',"\c6You are not an admin!");
			return;
		}
		
		%target = findClientByName(%target);
		
		if(!isObject(%client) || !isObject(%target))
		{
			messageClient(%client,'',"\c6That player doesn't exist!");
			return;
		}
		
		if(%level $= "" || %level <= 0)
		{
			messageClient(%client,'',"\c6You cannot set a player's level below one!");
			return;
		}
		
		if(%level == 1)
		{
			%target.maxEXP = 24;
			%target.EXP = 0;
			%target.level = 1;
			announce("\c4" @ %client.name @ "\c6 has set \c4" @ %target.name @ "\c6's level to \c4" @ %level);
			return;
		}
		
		else if(%level > %target.level)
		{
			%dif = %level - %target.level;
			%target.maxEXP = 24 + (12 * %dif);
		}
		
		else if(%level < %target.level)
		{
			%dif = %target.level - %level;
			%target.maxEXP = %target.maxEXP - (12 * %dif);
		}
		
		%target.level = %level;
		%target.EXP = 0;
		%target.clanPrefix = "\c6[\c4" @ %target.LevelColor @ %target.level @"\c6] \c7"@ %target.clanOldP;
		if(%target.level >= 10)
			%target.knifeCount=2;
		if(%target.level >= 20)
			%target.knifeCount=3;
		if(%target.level >= 30)
			%target.knifeCount=4;
		if(%target.level >= 40)
			%target.knifeCount=5;
		if(%target.level >= 50)
			%target.knifeCount=6;
		if(%target.level >= 60)
			%target.knifeCount=7;
		if(%target.level >= 70)
			%target.knifeCount=8;
		if(%target.level >= 80)
			%target.knifeCount=9;
		announce("\c4" @ %client.name @ "\c6 has set \c4" @ %target.name @ "\c6's level to \c4" @ %level);
	}
			
	function GameConnection::onDeath(%this,%obj,%killer,%type,%area)
	{
		parent::onDeath(%this,%obj,%killer,%type,%area);
		
		if(!$Levelmod::isEnabled)
			return;
		
		if(%this != %killer && %killer.getClassName() $= "GameConnection")
		{
			%EXP = getRandom(1,12);
			%killer.EXP += %EXP;
			if(%killer.EXP >= %killer.maxEXP)
			{
				%extra = %killer.EXP - %killer.maxEXP;
				%killer.EXP = %extra;
				%killer.maxEXP += 12;
				%killer.level += 1;
				schedule(1000, 0, saveLevel, %killer);
				announce("\c4" @ %killer.name @ " \c6has gained a level! \c6[\c4" @ %killer.level @ "\c6] [\c4" @ %killer.EXP @ "\c6/\c4" @ %killer.maxEXP @ "\c6]");
				%killer.clanPrefix = "\c6[\c4" @ %killer.LevelColor @ %killer.level @"\c6] \c7"@ %killer.clanOldP;
				
				if(%killer.level % 10 == 0)
				{
					if($KnifeAPI)
					{
						if(%killer.knifeCount == 0 || %killer.knifeCount $= "")
							%killer.knifeCount += 2;
						else
							%killer.knifeCount++;
						if(%killer.knifeCount <= $KnifeTotal)
							announce("\c4" @ %killer.name @ "\c6 has unlocked the \c4 " @ $Knife[%killer.knifeCount] @ "\c6!");
					}
					
					%client.rankCount++;
					%client.LevelTitle = $Rank[%client.rankCount];
					%client.LevelColor = $RankColor[%client.rankCount];
				}
				return;
			}
			messageClient(%killer,'',"\c6You have gained \c4" @ %EXP @ "\c6 EXP. \c6[\c4" @ %killer.EXP @ "\c6/\c4" @ %killer.maxEXP @ "\c6]");
		}
	}
};
activatePackage(Levelmod);
