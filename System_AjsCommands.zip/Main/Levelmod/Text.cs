$Rank[0] = "New Guy";
$RankColor[0] = "<color:333333>";

$Rank[1] = "Jagger";
$RankColor[1] = "<color:333333>";

$Rank[2] = "Crazy";
$RankColor[2] = "<color:9999FF>";

$Rank[3] = "Supreme";
$RankColor[3] = "<color:66CC66>";

$Rank[4] = "Overload";
$RankColor[4] = "<color:CCCC66>";

$Rank[5] = "Stalker";
$RankColor[5] = "<color:660066>";

$Rank[6] = "Dark Shadow";
$RankColor[6] = "<color:000099>";

$Rank[7] = "Max Payne";
$RankColor[7] = "<color:33CC66>";

$Rank[8] = "Overlord";
$RankColor[8] = "<color:660000>";

$Rank[9] = "God-Like";
$RankColor[9] = "<color:00FFFF>";

$Rank[10] = "Emperor";
$RankColor[10] = "<color:33FF00>";

$Rank[11] = "Supreme Hacker";
$RankColor[11] = "<color:FF0099>";

package LevelShow
{
	function GameConnection::onClientEnterGame(%client)
	{
		parent::onClientEnterGame(%client);
		if(%client.rankCount < 0 || %client.rankCount $= "")
			%client.rankCount = 0;
		
		schedule(1000, 0, showStats, %client);
	}
	
	function showStats(%client)
	{
		
		$GUIfont = "<font:arial:18>";
		$GUISC = "<color:f0f0f0>";
		if(isObject(%client) && isObject(%client.player))
		{
			if(!$Levelmod::isEnabled)
			{
				commandToClient(%client,'bottomprint',"",1,1);
				%client.clanPrefix = %client.clanOldP;
				
				cancel(%client.StatisticsLoop);
				%client.StatisticsLoop = schedule(2000, 0, ShowStats, %client);
				return;
			}
			
			if(%client.level == 1)
			{
				%client.LevelTitle = $Rank[0];
				%client.LevelColor = $RankColor[0];
			}
			
			if(%client.level >= 2 && %client.level <= 9)
			{
				%client.LevelTitle = $Rank[1];
				%client.LevelColor = $RankColor[1];
			}
			if(%client.level >= 10 && %client.level <= 19)
			{
				%client.LevelTitle = $Rank[2];
				%client.LevelColor = $RankColor[2];
			}
			if(%client.level >= 20 && %client.level <= 29)
			{
				%client.LevelTitle = $Rank[3];
				%client.LevelColor = $RankColor[3];
			}
			if(%client.level >= 30 && %client.level <= 39)
			{
				%client.LevelTitle = $Rank[4];
				%client.LevelColor = $RankColor[4];
			}
			if(%client.level >= 40 && %client.level <= 49)
			{
				%client.LevelTitle = $Rank[5];
				%client.LevelColor = $RankColor[5];
			}
			if(%client.level >= 50 && %client.level <= 59)
			{
				%client.LevelTitle = $Rank[6];
				%client.LevelColor = $RankColor[6];
			}
			if(%client.level >= 60 && %client.level <= 69)
			{
				%client.LevelTitle = $Rank[7];
				%client.LevelColor = $RankColor[7];
			}
			if(%client.level >= 70 && %client.level <= 79)
			{
				%client.LevelTitle = $Rank[8];
				%client.LevelColor = $RankColor[8];
			}
			if(%client.level >= 80 && %client.level <= 89)
			{
				%client.LevelTitle = $Rank[9];
				%client.LevelColor = $RankColor[9];
			}
			%C = %client.LevelColor;
			
			%LV = %client.LevelTitle;
			%LVL = %client.level;
			%XP = %client.EXP;
			%maxXP = %client.MaxEXP;
			commandToClient(%client,'bottomPrint', "<br>" @ $GUIfont @ $GUISC @ "<just:center>Rank: " @ %C @ %LV SPC %SC @ "\c6Level:" @ %C SPC %LVL SPC %SC @ "\c6XP:" @ %C SPC %XP @ %SC @ " / " @ %C @ %maxXP @ "<br><br><just:center>\c6Top Knifer: " @ %C @ $serverPlayer @ " [" @ $serverScore @ "] <br> \c6Top Level: "  @ %C @ $serverPlayerLevel @ " [" @ $serverLevel @ "]",3,1);
			
			
			//Prefix
			sendPrefix(%client);
				
			
			if(%client.isMember)
				%client.clanSuffix = "\c4CoRK";
			
			if(%client.score > $serverScore)
			{
				$serverPlayer = %client.name;
				$serverScore = %client.score;
				
				if(%client.name $= $serverPlayer)
					%skip = 1;
				else
					%skip = 0;
				
				if(!%skip)
					announce("\c4" @ $serverPlayer @ " \c6has gained the most score in the server \c4[" @ $serverScore @ "]");
			}
			if(%client.Level > $serverLevel)
			{
				$serverPlayerLEVEL = %client.name;
				$serverLevel = %client.level;
				
				if(%client.name $= $serverPlayer)
					%skip = 1;
				else
					%skip = 0;
				
				if(!%skip)
					announce("\c4" @ $serverPlayerLevel @ " \c6is the best level in the server! \c4[" @ $serverLevel @ "]");
			}
			cancel(%client.StatisticsLoop);
			%client.StatisticsLoop = schedule(2000, 0, ShowStats, %client);
			return;
		}
		cancel(%client.StatisticsLoop);
		%client.StatisticsLoop = schedule(2000, 0, ShowStats, %client);
	}

	function sendPrefix(%client)
	{
		if(!%client.isSuperAdmin && !%client.isAdmin && !%client.isModerator && !%client.isMember && !%client.isVIP){
			%client.clanPrefix = "\c7[" @ %client.LevelColor @ %client.level @ "\c7]" SPC %client.clanOldP;return;}
		if(%client.isSuperAdmin){
			%client.clanPrefix = "\c7[\c1SA\c7] [" @ %client.LevelColor @ %client.level @ "\c7]" SPC %client.clanOldP;return;}
		if(%client.isAdmin){
			%client.clanPrefix = "\c7[\c2A\c7] [" @ %client.LevelColor @ %client.level @ "\c7]" SPC %client.clanOldP;return;}
		if(%client.isModerator){
			%client.clanPrefix = "\c7[\c5MOD\c7] [" @ %client.LevelColor @ %client.level @ "\c7]" SPC %client.clanOldP;return;}
		if(%client.isVIP){
			%client.clanPrefix = "\c7[\c3VIP\c7] [" @ %client.LevelColor @ %client.level @ "\c7]" SPC %client.clanOldP;return;}
	}
};
activatePackage(LevelShow);


