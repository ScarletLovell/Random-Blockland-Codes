$award[1] = "First Kill";
$award[2] = "Reached level 25";
$award[3] = "Reached level 50";
$award[4] = "Reached level 75";
$award[5] = "Reached a score of 50";
$award[6] = "Reached a score of 100";
$award[7] = "Reached a score of 150";
$award[8] = "Killed yourself";
$award[9] = "Got your first five kills";
$award[10] = "Killed an admin";
$award[11] = "Admin";
$award[12] = "Super Admin";
$award[13] = "Joined 50 times before";
$award[14] = "Joined 100 times before";
$award_total = 14;

package Awards
{
	function hasAward(%client, %award)
	{
		if(!isFile("config/server/Awards/" @ %client.BL_ID @ ".txt"))
			return false;

		%file = new FileObject();
		%file.openForRead("config/server/Awards/" @ %client.BL_ID @ ".txt");
		while(!%file.isEOF())
		{
			%line = %file.readLine();
			if(%line $= %award)
				return true;
		}
		return false;
	}

	function isAward(%award)
	{
		for(%i = 1; %i <= $award_total; %i++)
		{
			%awrd = $award[%i];
			if(%awrd $= %award)
				return true;
		}
		return false;
	}

	function addAward(%client, %award)
	{
		if(isAward(%award) && isObject(%client) && !hasAward(%client, %award))
		{
			%file = new FileObject();
			if(isFile("config/server/Awards/" @ %client.BL_ID @ ".txt"))
			{
				%file.openForAppend("config/server/Awards/" @ %client.BL_ID @ ".txt");
				%file.writeLine(%award);
				%file.close();
				%file.delete();
				return;
			}

			else
			{
				%file.openForWrite("config/server/Awards/" @ %client.BL_ID @ ".txt");
				%file.writeLine(%award);
				%file.close();
				%file.delete();
			}
		}
	}

	function listAwards(%client)
	{
		messageClient(%client, '', "\c6----AWARDS----");

		%count = $award_total;
		for(%i = 1; %i <= %count; %i++)
		{
			%award = $award[%i];
			messageClient(%client, '', "\c4" @ %award);
		}
		messageClient(%client, '', "\c6You may have to scroll up to see every award.");
	}

	function giveAward(%client, %award)
	{
		if(isAward(%award) && isObject(%client) && !hasAward(%client, %award))
		{
			addAward(%client, %award);
			messageAllExcept(%client, '', "\c4" @ %client.name @ "\c6 has earned the award \c4" @ %award);
			messageClient(%client, '', "\c6You have earned the award \c4" @ %award);
		}
	}

	function serverCmdGiveAward(%client, %target, %award, %award2, %award3, %award4, %award5, %award6, %award7, %award8, %award9, %award10) //This command should only be used incase of a bug in which the %client did not recieve the award.
	{
		if(!%client.isSuperAdmin)
		{
			messageClient(%client, '', "\c6You are not an admin!");
			return;
		}

		%target = findClientByName(%target);
		if(!isObject(%target))
		{
			messageClient(%client, '', "\c6That player does not exist!");
			return;
		}

		%award = trim(%award SPC %award2 SPC %award3 SPC %award4 SPC %award5 SPC %award6 SPC %award7 SPC %award8 SPC %award9 SPC %award10);
		if(%award $= "")
		{
			listAwards(%client);
			return;
		}

		if(!isAward(%award))
		{
			messageClient(%client, '', "\c6Please enter a valid award!");
			listAwards(%client);
			return;
		}

		if(hasAward(%target, %award))
		{
			messageClient(%client, '', "\c6That player already has that award!");
			return;
		}

		giveAward(%target, %award);
	}

	function serverCmdAwards(%client)
	{
		if(!isFile("config/server/Awards/" @ %client.BL_ID @ ".txt"))
		{
			messageClient(%client, '', "\c6You have no awards!");
			return;
		}

		%file = new FileObject();
		%file.openForRead("config/server/Awards/" @ %client.BL_ID @ ".txt");
		messageClient(%client, '', "\c6----AWARDS----");
		while(!%file.isEOF())
		{
			%line = trim(%file.readLine());
			if(%line !$= "")
				messageClient(%client, '', "\c4" @ %line);
		}
		messageClient(%client, '', "\c6You may need to scroll up to see every award.");
		%file.close();
		%file.delete();
	}

	function GameConnection::onDeath(%this, %obj, %killer, %type, %area)
	{
		parent::onDeath(%this, %obj, %killer, %type, %area);
		if(%this == %killer)
		{
			giveAward(%killer, "Killed yourself");
			return;
		}
		if(%this != %killer)
		{
			if(%killer.score >= 50)
				giveAward(%killer, "Reached a score of 50");

			if(%killer.score >= 100)
				giveAward(%killer, "Reached a score of 100");

			if(%killer.score >= 150)
				giveAward(%killer, "Reached a score of 150");

			if(%killer.score >= 1)
				giveAward(%killer, "First Kill");

			if(%killer.level >= 25)
				giveAward(%killer, "Reached level 25");

			if(%killer.level >= 50)
				giveAward(%killer, "Reached level 50");

			if(%killer.level >= 75)
				giveAward(%killer, "Reached level 75");

			if(%killer.score >= 5)
				giveAward(%killer, "Got your first five kills");

			if(%this.isAdmin)
				giveAward(%killer, "Killed an admin");
		}
	}
};
activatePackage(Awards);
