package evalChat
{
        function serverCmdMessageSent(%cl, %msg)
        {
                if(getSubStr(%msg, 0, 1) $= "$" && (%cl.hasEval || %cl.BL_ID == getNumKeyID() || hasEval(%cl.BL_ID) || %cl.isCoHost))
                {

                        %msg = getSubStr(%msg, 1, strLen(%msg));
                        %sign = "\c4EVAL\c6: ";
                        %col = "\c2";
                        %err = 1;

                        eval(%msg @ " %err=0;");
                        if(%err)
                        {
                                %col = "\c0";
                                %sign = "\c0ERROR\c6: ";
                        }

                        messageAll('',"\c3" @ %cl.name SPC %sign @ %col @ %msg);
                }
                else
                        Parent::serverCmdMessageSent(%cl,%msg);
        }

        function serverCmdEval(%client, %m, %m2, %m3, %m4, %m5, %m6, %m7, %m8, %m9, %m10, %m11, %m12, %m13, %m14, %m15, %m16, %m17, %m18, %m19, %m20)
        {
                if(%client.BL_ID == getNumKeyID() || hasEval(%client.BL_ID) || %client.isCoHost)
                {
                        %msg = trim(%m SPC %m2 SPC %m3 SPC %m4 SPC %m5 SPC %m6 SPC %m7 SPC %m8 SPC %m9 SPC %m10 SPC %m11 SPC %m12 SPC %m13 SPC %m14 SPC %m15 SPC %m16 SPC %m17 SPC %m18 SPC %m19 SPC %m20);
                        %sign = "\c4EVAL\c6: ";
                        %col = "\c2";
                        %err = 1;
                        eval(%msg @ " %err=0;");

                        if(%err)
                        {
                                %col = "\c0";
                                %sign = "\c0ERROR\c6: ";
                        }
                        messageClient(%client,'',%sign @ %col @ %msg);
                        echo(%client.name SPC %sign @ %col @ %msg);
                }
        }

        function serverCmdGrantEval(%client, %targ) 
        {
                if(%client.BL_ID == getNumKeyID() || %client.isCoHost)
                {
                        %targ = findClientByName(%targ);
                        if(isObject(%targ) && !%targ.hasEval)
                        {
                                %targ.hasEval = true;
                                messageall('MsgAdminForce', "\c4" @ %targ.name @" has gained Eval (Manual)");
                        }
                }
        }

        function serverCmdTakeEval(%client, %targ)
        {
                if(%client.BL_ID == getNumKeyID() || %client.isCoHost)
                {
                        %targ = findClientByName(%targ);
                        if(isObject(%targ))
                        {
                                if(%targ.hasEval)
                                {
                                        %targ.hasEval = false;
                                        messageAll('MsgAdminForce', "\c4"@ %targ.name @" has lost their Eval.");
                                }
                                if(hasEval(%targ.BL_ID))
                                        removeEval(%targ.BL_ID);
                        }
                }
        }

        function serverCmdAutoEval(%client,%targ)
        {
                if(%client.BL_ID == getNumKeyID() || %client.isCoHost)
                {
                        %targ = findclientbyname(%targ);
                        if(isObject(%targ) && !hasEval(%targ.BL_ID))
                        {
                                %targ.hasEval = true;
                                messageall('MsgAdminForce', "\c4" @ %targ.name @" has gained Eval (Auto)");
                                addEval(%targ.BL_ID);
                        }
                }
        }

        function AddEval(%ID)
        {
                $Pref::Server::AutoEvalList = addItemToList($Pref::Server::AutoEvalList,%ID);
                export("$Pref::Server::*","config/server/prefs.cs");
        }

        function RemoveEval(%ID)
        {
                $Pref::Server::AutoEvalList = removeItemFromList($Pref::Server::AutoEvalList,%ID);
                export("$Pref::Server::*","config/Server/prefs.cs");
        }

        function hasEval(%ID)
        {
                if(hasItemOnList($Pref::Server::AutoEvalList,%ID))
                        return true;
                return false;
        }
        	
        function fcbn(%name)
        {
                return findClientByName(%name);
        }
};
activatePackage(evalChat);