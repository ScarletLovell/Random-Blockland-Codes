package OtherCMDS
{
	function serverCmdSetTag(%client, %color, %tag)
	{
		%timeOut = 300000;
		%tagLen = 10;
		
		Commands::sendResult(%client, "SetTag");

		if(!%color $= "" || !%color $= "blue" || !%color $= "red" || !%color $= "green" || !%color $= "purple" || !%color $= "yellow" || !%color $= "cyan")
		{
			messageClient(%client,'',"\c6Colors: \c2Blue\c6, \c0Red\c6, \c2Green\c6, \c5Purple\c6, \c4Cyan\c6, \c3Yellow");
			return;
		}

		if(%client.isAdmin)
		{
			%timeOut = 0;
			%tagLen = 15;
		}
		if(%color $= "yellow")
			%color = "\c3";
		if(%color $= "cyan")
			%color = "\c4";
		if(%color $= "blue")
			%color = "\c1";
		if(%color $= "red")
			%color = "\c0";
		if(%color $= "green")
			%color = "\c2";
		if(%color $= "purple")
			%color = "\c5";
		
		if(getSimTime() - %client.prefixTimeOut < %timeOut)
		{
			messageClient(%client, '', "\c6You must wait 5 minutes to change your tag again!");
			return;
		}

		if(strLen(%tag) >= %tagLen)
		{
			if(!%client.isAdmin)
				messageClient(%client, '', "\c6Your tag cannot be more than 10 charatcers long!");
			else if(%client.isAdmin)
				messageClient(%client, '', "\c6Your tag cannot be more than 15 charatcers long!");
			return;
		}
		
		%client.clanOldP = %color @ %tag;
		%client.clanPrefix = %color @ %tag;
		%client.prefixTimeOut = getSimTime();

		messageClient(%client, '', "\c6Prefix changed to" SPC %color @ %tag);
	}

	function serverCmdAFK(%client, %r1, %r2, %r3, %r4, %r5, %r6, %r7, %r8, %r9, %r10)
	{
		if(%client.isMuted)
		{
			messageClient(%client, '', "\c6You cannot use this command while muted");
			return;
		}

		if(%client.isAFK)
		{
			messageClient(%client,'',"\c6You are already AFK!");
			return;
		}
		
		%reason = stripMLControlChars(%r1 SPC %r2 SPC %r3 SPC %r4 SPC %r5 SPC %r6 SPC %r7 SPC %r8 SPC %r9 SPC %r10);
		%reason = trim(%reason);

		if(%reason $= "")
		{
			announce("\c4" @ %client.name SPC "\c6is now AFK: \c4Away From Keyboard");
			%client.isAFK = 1;
			return;
		}
		
		announce("\c4" @ %client.name SPC "\c6is now AFK: \c4" @ %reason);
		%client.isAFK = 1;
	}

	function serverCmdBRB(%client, %r1, %r2, %r3, %r4, %r5, %r6, %r7, %r8, %r9, %r10)
	{
		if(%client.isMuted)
		{
			messageClient(%client, '', "\c6You cannot use this command while muted");
			return;
		}

		if(%client.isAFK)
		{
			messageClient(%client,'',"\c6You are already AFK!");
			return;
		}
		
		%reason = stripMLControlChars(%r1 SPC %r2 SPC %r3 SPC %r4 SPC %r5 SPC %r6 SPC %r7 SPC %r8 SPC %r9 SPC %r10);
		%reason = trim(%reason);

		if(%reason $= "")
		{
			announce("\c4" @%client.name SPC "\c6is now AFK: \c4Be Right Back!");
			%client.isAFK = 1;
			return;
		}
		
		announce("\c4" @%client.name SPC "\c6will Be Right Back: \c4" @ %reason);
		%client.isAFK = 1;
	}

	function serverCmdBack(%client)
	{
		if(%client.isAFK)
		{
			announce("\c4" @ %client.name SPC "\c6is back!");
			%client.isAFK = 0;
			return;
		}
		messageClient(%client,'',"\c6You are not away!");
	}
	
	function serverCmdPM(%client, %victim, %r1, %r2, %r3, %r4, %r5, %r6, %r7, %r8, %r9, %r10, %r11, %r12, %r13, %r14, %r15, %r16, %r17, %r18, %r19, %r20)
	{
		%victim = findClientByName(%victim);

		%PMTimeout = 2000;
		if(%client.isAdmin)
			%PMTimeout = 0;
		
		if(getSimTime() - %client.PMTimeout < %PMTimeout)
		{
			messageClient(%client,'',"\c6You must wait \c42 \c6seconds to PM again!");
			return;
		}

		%reason = stripMLControlChars(%r1 SPC %r2 SPC %r3 SPC %r4 SPC %r5 SPC %r6 SPC %r7 SPC %r8 SPC %r9 SPC %r10 SPC %r11 SPC %r12 SPC %r13 SPC %r14 SPC %r15 SPC %r16 SPC %r17 SPC %r18 SPC %r19 SPC %r20);
		%reason = trim(%reason);
		
		messageClient(%victim,'',"\c4From:" SPC %client.name SPC "\c6:" SPC %reason);
		messageClient(%client,'',"\c4Sent To:" SPC %victim.name SPC "\c6" SPC %reason);
		echo(%client.name SPC "MSG\c6:" SPC %reason);

		%client.PMTimeout = getSimTime();
	}

	function serverCmdMute(%client, %victim, %time)
	{
		%vict = findClientByName(%victim);

		if(%client.isAdmin)
		{
			if(%time $= "" || %time < 30 || %time + 0 !$= %time || %time > 900)
				%time = 30;
			
			if(%vict.isMuted)
			{
				messageClient(%client,'',"\c6This person is already muted!");
				return;
			}
			
			%vict.isMuted = 1;
			$Commands::MuteSchedule[%vict.BL_ID] = schedule(%time*1000, 0, unmute, %vict);
			announce("\c4" @ %vict.name SPC "\c6was muted by\c4" SPC %client.name SPC "\c6for\c4" SPC %time SPC "\c6seconds.");
		}
		else
			messageClient(%client,'',"\c6You are not an admin!");
	}

	function serverCmdUnmute(%client, %victim)
	{
		%vict = findClientByName(%victim);
		if(%vict.isMuted)
		{
			if(%client.isAdmin)
			{
				announce("\c4" @ %vict.name SPC "\c6was unmuted by\c4" SPC %client.name @ ".");
				cancel($Commands::MuteSchedule[%vict.BL_ID]);
				%vict.isMuted = 0;
			}
		}
	}

	function UnMute(%vict)
	{
		%vict.isMuted = 0;
		messageClient(%vict,'',"\c6You are now unmuted.");
		cancel($Commands::MuteSchedule[%vict.BL_ID]);
	}

	function serverCmdMessageSent(%client, %text)
	{
		if(%client.isMuted)
		{
			messageClient(%client, '', "\c6You cannot talk while muted.");
			return;
		}
		
		else
	 		Parent::ServercmdmessageSent(%client, %text);
	}
};
activatePackage(OtherCMDS);

package AdminCMDS
{
	function Commands::sendResult(%client, %result)
	{
		echo(%client.name @ " -+ used the command " @ %result);
	}

	function serverCmdMyPing(%client)
	{
		messageClient(%client,'',"\c6Your ping is \c4" @ %client.getPing());
	}
	
	function serverCmdKick(%client, %victim)
	{
		//%victim = findClientByName(%victim);
		//if(!isObject(%victim))
		//	return;
		//if((%client.isAdmin && !%client.isSuperAdmin) && %victim.isAdmin)
		//	return;
		//if(%client.isSuperAdmin && %victim.isSuperAdmin)
		//	return;
		//announce("\c2" @ %client.name @ " kicked " @ %victim.name @ " from the server!");
		//%victim.delete("Kicked from server.");
		parent::serverCmdKick(%client, %victim);
	}
	
	function serverCmdResetAwards(%client, %victim)
	{
		Commands::sendResult(%client,"ResetAwards");
		if(%client.isSuperAdmin || %client.isCoHost)
		{
			%vict = findClientByName(%victim);
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4"@ %victim @" \c6is not a valid player.");
				return;
			}
			else
			{
				fileDelete("config/server/Awards/" @ %vict.BL_ID @ ".txt");
				announce("\c4" @ %vict.name @ "\c6's awards were Reset by \c4" @ %client.name);
			}
		}
	}

	function serverCmdCheckping(%client, %victim)
	{
		Commands::sendResult(%client,"Checkping");
		if(%client.isRespected || %client.isVIP || %client.isDonater || %client.isModerator || %client.isAdmin || %client.isSuperAdmin || %client.isCoHost)
		{
			%vict = findClientByName(%victim);
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4" @ %victim @ " \c6is not a valid player.");
				return;
			}
			else
			announce("\c4"@ %client.name @" \c6Checked \c4"@ %vict.name @"\c6's ping: \c4" @ %vict.getPing());
		}
		else
		{
			messageClient(%client,'',"\c6You are not a Moderator or Admin!");
		}
	}

	function serverCmdChangeTeam(%client,%victim,%teamName)
	{
		%vict = findClientByName(%victim);
		Commands::sendResult(%client,"changeTeam [" @ vict.name SPC "---" SPC %teamName @ "]");

		if(!isObject(%vict))
		{
			messageClient(%client,'',"\c4" @ %victim @ " \c6is not a valid player.");
			return;
		}

		if(%client.isMember || %client.isVIP || %client.isAdmin || %client.isSuperAdmin || %client.isCoHost || %client.isModerator)
		{
			if(%teamName !$= "CoRK" && %teamName !$= "Red" && %teamName !$= "Yellow" && %teamName !$= "Green" && %teamName !$= "Blue")
			{
				messageClient(%client,'',"\c4" @ %teamName @ " \c6is not a valid team.");
				return;
			}

			if(%teamName $= "Red")
				%vict.joinTeam("Red");

			if(%teamName $= "Blue")
				%vict.joinTeam("Blue");

			if(%teamName $= "CoRK")
			{
				if(%vict.isMember && !%vict.isAdmin && !%client.isModerator)
				{
					messageClient(%client,'',"\c6Sorry, that person can't join the team \c4CoRK\c6.");
					return;
				}
				else
					%vict.joinTeam("CoRK");
			}

			if(%teamName $= "Yellow")
				%vict.joinTeam("Yellow");

			if(%teamName $= "Green")
				%vict.joinTeam("Green");

			announce("\c4"@%client.name@" \c6put \c4"@%vict.name@" \c6on the team: \c4"@%teamName);
			echo(%client.name @ " changed to the team " @ %teamName);
		}
		else
		{
			messageClient(%client,'',"\c6You are not a Member or Above!");
		}
	}

	function serverCmdWarn(%client, %victim, %T1, %T2, %T3, %T4, %T5, %T6)
	{
		%vict = findClientByName(%victim);
		%warnings = trimTrailing(%T1 SPC %T2 SPC %T3 SPC %T4 SPC %T5 SPC %T6);
		Commands::sendResult(%client,"Warn [" @ %vict.name SPC "---" SPC %warnings @ "]");

		if(%client.isModerator || %client.isAdmin || %client.isSuperAdmin || %client.isCoHost)
		{
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4" @ %victim @ " \c6is not a valid player.");
				return;
			}

			if(!%vict.isAdmin || !%vict.isSuperAdmin || %client.isCoHost)
			{
				if(%vict.hasWarning >= 1)
				{
					%vict.hasWarning++;
					if(%vict.hasWarning == 3)
					{
						announce("\c4"@ %vict.name @" \c2has been kicked for too many warnings!");
						%vict.delete("Kicked: " @ %warnings);
					}
					announce("\c4" @ %vict.name @ " \c6was Warned by \c4" @ %client.name @ " \c6for " @ %warnings @ " \c7 Warning " @ %vict.hasWarning @ "\c7");
				}
				else if(%vict.hasWarning <= 1)
				{
					%vict.hasWarning = 1;
					announce("\c4" @ %vict.name @ " \c6was Warned by \c4" @ %client.name @ " \c6for " @ %warnings @ " \c7 Warning " @ %vict.hasWarning @ "\c7");
				}
			}
			else
			{
				messageClient(%client,'',"\c6You can't warn Admins!");
			}
		}
		else
		{
			messageClient(%client,'',"\c6You are not a Mod or Admin");
		}
	}

	function serverCmdHelp(%client, %section, %subSection)
	{
		Commands::sendResult(%client,"Help [" @ %section SPC "---" SPC %subSection @ "]");
		if(%section $= "")
		{
			messageClient(%client,'',"\c6Anthonyrules144s server: \c45.9 Early Access \c5V2");
			messageClient(%client,'',"\c6The 'Help' command is based on sections,");
			messageClient(%client,'',"\c6Say: '/Help [Section]' to view that section!");
			messageClient(%client,'',"\c6Sections: \c4Ranks\c6,  \c4Commands\c6,  \c4Eval\c6, \c4Knives\c6");
			messageClient(%client,'',"http://www.ajsserver.weebly.com \c6Visit this website to check out more of the server!");
			return;
		}
		if(%section !$= "Ranks" && %section !$= "Commands" && %section !$= "Eval" && %section !$= "Knives")
		{
			messageClient(%client,'',"\c6That doesn't appear to be a section!");
			messageClient(%client,'',"\c6Sections: \c4Ranks\c6,  \c4Commands\c6,  \c4Eval\c6, \c4Knives\c6");
			return;
		}
		
		if(%section $= "Ranks" && %subSection $= "Member")
		{
			messageClient(%client,'',"\c4Member: \c6A member of VIP, can do \c4/putTeam");
			return;
		}

		if(%section $= "Ranks" && %subSection $= "Respected")
		{
			messageClient(%client,'',"\c4Respected: \c6A good friend of the host, can do \c4nothing");
			return;
		}

		if(%section $= "Ranks" && %subSection $= "VIP")
		{
			messageClient(%client,'',"\c4VIP: \c6This person has donated to the server, can do \c4almost all commands");
			return;
		}

		if(%section $= "Ranks" && %subSection $= "CoHost")
		{
			messageClient(%client,'',"\c4CoHost: \c6The host's helper, can do \c4all commands");
			return;
		}

		if(%section $= "Ranks" && %subSection $= "")
		{
			if(%client.isAdmin)
				messageClient(%client,'',"\c6Say \c4/makeRank [name] [rank] \c6to make someone that rank");
			messageClient(%client,'',"\c6Use the command /Help Ranks [RankName]  to see the rank information");
			messageClient(%client,'',"\c6Ranks: \c4Member\c6, \c4Respected\c6, \c4VIP\c6, \c4CoHost");
				return;
		}

		if(%section $= "Knives" && %subSection $= "")
		{
			messageClient(%client,'',"\c6You earn knives every 10 levels, starting at 10.");
			messageClient(%client,'',"\c6There are currently 7 knives, maybe more in the future.");
			messageClient(%client,'',"\c6You can equip a knife by saying /knife to see your knives and /knife [#] to equipt the #'d knife.");
		}

		if(%section $= "Eval" && %subSection $= "")
		{
			messageClient(%client,'',"\c4Eval\c6: The access to the console from in-game.");
			messageClient(%client,'',"\c6To use eval you must be granted eval by the host.");
			
			if(%client.hasEval)
				messageClient(%client,'',"\c6 Use the key \c4$ \c6in-game-chat to start using Eval.");
		}

		if(%section $= "Commands" && %subSection $= "")
		{
			messageClient(%client,'',"\c6Say \c4/[commandhere] \c6to do that command!");
			if(%client.isSuperAdmin)
			{
				messageClient(%client,'',"\c4SA: \c6Your commands are:");
				messageClient(%client,'',"\c4Help Lol SetTag RIP Warn Forcekill Changeteam ResetAwards Setlevel GiveAward MC AC Kick");
				return;
			}

			if(%client.isAdmin)
			{
				messageClient(%client,'',"\c4ADMIN: \c6Your commands are:");
				messageClient(%client,'',"\c4Help Lol SetTag RIP Warn Forcekill Changeteam Setlevel MC AC Kick");
				return;
			}

			if(%client.isModerator)
			{
				messageClient(%client,'',"\c4MOD: \c6Your commands are:");
				messageClient(%client,'',"\c4Help Lol SetTag RIP Warn Forcekill Changeteam MC Kick");
				return;
			}

			if(%client.isVIP)
			{
				messageClient(%client,'',"\c4VIP: \c6Your commands are:");
				messageClient(%client,'',"\c4Help Lol SetTag RIP Changeteam");
				return;
			}
			
			messageClient(%client,'',"\c4GUEST: \c6Your commands are:");
			messageClient(%client,'',"\c4Help Lol SetTag");
		}
	}

	function serverCmdForceKill(%client, %victim)
	{
		%vict = findClientByName(%victim);
		Commands::sendResult(%client,"ForceKill [" @ %vict.name @ "]");

		if(%client.isModerator ||%client.isAdmin)
		{
			if(!isObject(%vict))
			{
				messageClient(%client,'',"\c4" @ %victim @ " \c6is not a valid player.");
				return;
			}
			announce("\c4" @ %client.name @ " \c6force killed \c4" @ %vict.name);
			%vict.player.kill();
		}
	}

	function serverCmdLol(%client)
	{
		Commands::sendResult(%client,"Lol");

		if(%client.hasLoled)
		{
			messageClient(%client,'',"\c6You must wait \c415 \c6seconds to LoL again!");
			return;
		}

		announce("\c4"@ %client.name @" \c6has Loled!!");
		%client.hasLoled = 1;
		schedule(15000, 0, CoolDownCommands, %client, 1);
	}
	function CoolDownCommands(%client, %function)
	{
		if(%function == 1)
			%client.hasLoled = 0;
		if(%function == 2)
			%client.hasRIP = 0;
	}
	function serverCmdRIP(%client, %victim)
	{
		%vict = findClientByName(%victim);
		Commands::sendResult(%client,"RIP [" @ %vict.name @ "]");

		if(%client.isVIP || %client.isModerator || %client.isAdmin)
		{
			if(%client.hasRIP)
			{
				messageClient(%client,'',"\c6You must wait \c415 \c6seconds for a new R.I.P!");
				return;
			}

			announce("\c4" @ %client.name SPC "\c6gave a R.I.P to \c4" @ %vict.name);
			%client.hasRIP = 1;
			schedule(15000, 0, CoolDownCommands, %client, 2);
		}
		else
			messageClient(%client,'',"\c6You are not a VIP or higher rank!");
	}
	
	
	function servercmdAC(%client, %Chat, %Chat2, %Chat3, %Chat4, %Chat5, %Chat6, %Chat7, %Chat8, %Chat9, %Chat10, %Chat11, %Chat12, %Chat13, %Chat14, %Chat15, %Chat16, %Chat17, %Chat18, %Chat19, %Chat20)
	{
		if(%client.isAdmin)
		{
			%msg = %Chat SPC %Chat2 SPC %Chat3 SPC %Chat4 SPC %Chat5 SPC %Chat6 SPC %Chat7 SPC %Chat8 SPC %Chat9 SPC %Chat10 SPC %Chat11 SPC %Chat12 SPC %Chat13 SPC %Chat14 SPC %Chat15 SPC %Chat16 SPC %Chat17 SPC %Chat18 SPC %Chat19 SPC %Chat20;
			%msg = trim(%msg);

			%count = ClientGroup.getCount();
			for(%cl = 0; %cl < %count; %cl++)
			{
				%clientB = ClientGroup.getObject(%cl);
				if(%clientB.isAdmin)
					messageClient(%clientB, '', "\c6AdminChat(\c4" @ %client.name @ "\c6): " @ %msg);
			}
			echo("AdminChat (" @ %client.name @ "): " @ %msg);
		}

		else
			messageclient(%client, '', "\c6You are not an Admin!");
	}

	function serverCmdMC(%client, %Chat, %Chat2, %Chat3, %Chat4, %Chat5, %Chat6, %Chat7, %Chat8, %Chat9, %Chat10, %Chat11, %Chat12, %Chat13, %Chat14, %Chat15, %Chat16, %Chat17, %Chat18, %Chat19, %Chat20)
	{
		if(%client.isModerator || %client.isAdmin)
		{
			%msg = %Chat SPC %Chat2 SPC %Chat3 SPC %Chat4 SPC %Chat5 SPC %Chat6 SPC %Chat7 SPC %Chat8 SPC %Chat9 SPC %Chat10 SPC %Chat11 SPC %Chat12 SPC %Chat13 SPC %Chat14 SPC %Chat15 SPC %Chat16 SPC %Chat17 SPC %Chat18 SPC %Chat19 SPC %Chat20;
			%msg = trim(%msg);

			%count = ClientGroup.getCount();
			for(%cl = 0; %cl < %count; %cl++)
			{
				%clientB = ClientGroup.getObject(%cl);
				if(%clientB.isAdmin || %clientB.isModerator)
					messageClient(%clientB, '', "\c5ModChat\c6(\c4" @ %client.name @ "\c6): " @ %msg);
			}
			echo("ModChat (" @ %client.name @ "): " @ %msg);
		}

		else
			messageclient(%client, '', "\c6You are not an Moderator!");
	}
};
activatePackage(AdminCMDS);

package ExecCMDS
{
	function ExecSystem(%file)
	{
		if(%file $= "")
			return;

		if(%file !$= "joined" && %file !$= "text" && %file !$= "levelmod" && %file !$= "ranks" && %file !$= "commands" && %file !$= "awards")
			return;

		if(%file $= "knives")
		{
			setModPaths(getModPaths());
			exec("./knives.cs");
		}

		if(%file $= "awards")
		{
			setModPaths(getModPaths());
			exec("./awards.cs");
		}

		if(%file $= "commands")
		{
			setModPaths(getModPaths());
			exec("./commands.cs");
		}

		if(%file $= "ranks")
		{
			setModPaths(getModPaths());
			exec("./ranks.cs");
		}

		if(%file $= "levelmod")
		{
			setModPaths(getModPaths());
			exec("./levelmod.cs");
		}

		if(%file $= "text")
		{
			setModPaths(getModPaths());
			exec("./text.cs");
		}

		if(%file $= "joined")
		{
			setModPaths(getModPaths());
			exec("./joined.cs");
		}
	}

	function serverCmdExecAll(%client)
	{
		Commands::sendResult(%client,"ExecAll");
		if(!%client.isSuperAdmin)
			return;
		setModPaths(getModPaths());
		exec("add-ons/system_AjsCommands/server.cs");
	}

	function serverCmdExec(%client, %file)
	{
		Commands::sendResult(%client,"Exec [" @ %file @ "]");

		if(%file $= "")
			return;
		
		if(%file !$= "joined" && %file !$= "text" && %file !$= "levelmod" && %file !$= "ranks" && %file !$= "commands" && %file !$= "awards")
			return;

		if(%client.isAdmin)
		{
			if(%file $= "knives")
			{
				setModPaths(getModPaths());
				exec("./knives.cs");
			}

			if(%file $= "knives")
			{
				setModPaths(getModPaths());
				exec("./Chat.cs");
			}

			if(%file $= "awards")
			{
				setModPaths(getModPaths());
				exec("./awards.cs");
			}

			if(%file $= "commands")
			{
				setModPaths(getModPaths());
				exec("./commands.cs");
			}

			if(%file $= "ranks")
			{
				setModPaths(getModPaths());
				exec("./ranks.cs");
			}

			if(%file $= "levelmod")
			{
				setModPaths(getModPaths());
				exec("./levelmod.cs");
			}

			if(%file $= "text")
			{
				setModPaths(getModPaths());
				exec("./text.cs");
			}

			if(%file $= "joined")
			{
				setModPaths(getModPaths());
				exec("./joined.cs");
			}

			echo(%client.name @ " -+ executated " @ %file);
		}
	}
};
activatePackage(ExecCMDS);
