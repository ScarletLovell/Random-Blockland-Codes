//By Anthonyrules144
if($GameModeArg $= "Add-Ons/Gamemode_KnifeTDM/gamemode.txt"){
	$Pref::Server::Name    =   "TEKP: KnifeTDM";}

if($GameModeArg $= "Add-Ons/Gamemode_Freebuild/gamemode.txt"){
	$Pref::Server::Name    =   "Speedkart";}
	
if($Pref::Server::Name $= "TEKP: KnifeTDM"){
	$Levelmod::isEnabled   =   1;}

if($Pref::Server::Name $= "Speedkart"){
	$Levelmod::isEnabled   =   0;
	$Awards::Speedkart     =   1;}
else
	$Awards::Speedkart     =   0;
	
//----------//
//Levelmodzz//
//----------//
exec("./Levelmod/Levelmod.cs");
exec("./Levelmod/Text.cs");
exec("./Levelmod/Saving.cs");


//----------//
//Otherstuff//
//----------//
exec("./Awards.cs");
exec("./Eval.cs");
exec("./Commands.cs");
exec("./Ranks.cs");
exec("./Chat.cs");
exec("./Voting.cs");
