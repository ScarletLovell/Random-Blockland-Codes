datablock StaticShapeData(votingBarShapeData)
{
	shapeFile = "Add-Ons/System_AjsCommands/Shapes/cube.dts";
};

datablock StaticShapeData(VotingTextEmptyShape)
{
	shapefile = "base/data/shapes/empty.dts";
};

$Voting::VoteTime = 60000; //The time the vote lasts

package Voting
{
	function serverCmdStartVote(%client, %name, %option, %option2, %option3, %option4)
	{
		if(%client.isAdmin)
		{
			if(!$Voting::IsVoting)
			{
				%name = strReplace(%name, "_", " "); //Replace _ with space
				
				//Set our variables
				$Voting::IsVoting = 1;
				$Voting::TotalVotes = 0;
				$Voting::Session = %name;
				$Voting::Options = %option SPC %option2 SPC %option3 SPC %option4;
				$Voting::Options = trim($Voting::Options); //Remove spaces (This also removes empty variables)
				if(%client.isAdmin)
					$Voting::AdminLevel = 1;
				else if(%client.isSuperAdmin)
					$Voting::AdminLevel = 2;
				
				createVotingBars(getWordCount($Voting::Options)); //Create the bars based on the word count
				
				announce("\c4" @ %client.name @ "\c6 has started a vote for \c4" @ %name @ "\c6. Use \c4/vote [Option]\c6 to vote!");
				
				%options = "\c4" @ $Voting::Options;				//Make the options appear cyan
				%options = strReplace(%options, " ", "\c6,\c4 ");	//Replace spaces with white commas and then set it back to cyan
				%options = strReplace(%options, "_", " ");			//Replace _ with space
				
				announce("\c6The options are \c4" @ %options @ "\c6.");
				$Voting::EndVoteLoop = schedule($Voting::VoteTime, 0, endVotingSession); //Schedule the vote end
			}
			else
				messageClient(%client,'',"\c6There is already a voting session!");
		}
		else
			messageClient(%client,'',"\c6You are not an Admin!");
	}
	
	function serverCmdVote(%client, %option, %option2, %option3, %option4, %option5, %option6, %option7, %option8, %option9, %option10, %option11, %option12, %option13, %option14)
	{
		if($Voting::IsVoting && !%client.hasVoted)
		{
			%options = %option SPC %option2 SPC %option3 SPC %option4 SPC %option5 SPC %option6 SPC %option7 SPC %option8 SPC %option9 SPC %option10 SPC %option11 SPC %option12 SPC %option13 SPC %option14;
			%options = trimTrailing(%options);
			%option = strReplace(%options, " ", "_");
			for(%i = 0; %i < getWordCount($Voting::Options); %i++)
			{
				%opt = getWord($Voting::Options, %i);
				if(%option $= %opt)
				{
					announce("\c4" @ %client.name @ "\c6 has voted \c4" @ strReplace(%opt, "_", " ") @ "\c6.");
					messageClient(%client,'',"\c6You can use \c4/revote [Option]\c6 to change your vote.");
					%client.votingBar = %i;
					votingHandling(%opt, %i, 1, %client.votingBar);
					%client.hasVoted = 1;
					return;
				}
			}
			%listOptions = strReplace($Voting::Options, " ", "\c6, \c4");
			%listOptions = strReplace(%listOptions, "_", " ");
			messageClient(%client,'',"\c6There is no option for that!");
			messageClient(%client,'',"\c6The options are \c4" @ %listOptions @ "\c6.");
		}
		
		if(!$Voting::IsVoting)
			messageClient(%client,'',"\c6There is no voting session going on!");
		if(%client.hasVoted)
			messageClient(%client,'',"\c6You cannot vote again!");
	}
	
	function serverCmdReVote(%client, %option, %option2, %option3, %option4, %option5, %option6, %option7, %option8, %option9, %option10, %option11, %option12, %option13, %option14)
	{
		if($Voting::IsVoting && %client.hasVoted && !%client.hasReVoted)
		{
			%options = %option SPC %option2 SPC %option3 SPC %option4 SPC %option5 SPC %option6 SPC %option7 SPC %option8 SPC %option9 SPC %option10 SPC %option11 SPC %option12 SPC %option13 SPC %option14;
			%options = trimTrailing(%options);
			%option = strReplace(%options, " ", "_");
			for(%i = 0; %i < getWordCount($Voting::Options); %i++)
			{
				%opt = getWord($Voting::Options, %i);
				if(%option $= %opt)
				{
					if(%i == %client.votingBar)
					{
						messageClient(%client,'',"\c6You can't vote for the same thing!");
						return;
					}
					
					announce("\c4" @ %client.name @ "\c6 has changed their vote to \c4" @ strReplace(%opt, "_", " ") @ "\c6.");
					votingHandling(%opt, %i, 0, %client.votingBar);
					%client.votingBar = %i;
					%client.hasReVoted = 1;
					return;
				}
			}
			%listOptions = strReplace($Voting::Options, " ", "\c6, \c4");
			%listOptions = strReplace(%listOptions, "_", " ");
			messageClient(%client,'',"\c6There is no option for that!");
			messageClient(%client,'',"\c6The options are \c4" @ %listOptions @ "\c6.");
		}
		
		if(!$Voting::IsVoting)
			messageClient(%client,'',"\c6There is no voting session going on!");
		if(%client.hasReVoted)
			messageClient(%client,'',"\c6You cannot vote again!");
	}
	
	function serverCmdCancelVote(%client)
	{
		if(%client.isAdmin && $Voting::IsVoting)
		{
			if((%client.isAdmin && !%client.isSuperAdmin) && $Voting::AdminLevel == 2)
			{
				messageClient(%client, '', "\c6You cannot cancel a vote started by a Super Admin!");
				return;
			}

			cancel($Voting::EndVoteLoop);
			announce("\c4" @ %client.name @ "\c6 has ended the voting session for \c4" @ $Voting::Session @ "\c6.");
			votingCleanup();
		}
		
		if(!%client.isAdmin)
			messageClient(%client,'',"\c6You are not an Admin!");
		if(%client.isAdmin && !$Voting::IsVoting)
			messageClient(%client,'',"\c6There is no voting session going on!");
	}
	
	function votingHandling(%option, %bar, %increaseVote, %previousBar)
	{
		if(%increaseVote) //Used for /vote
		{
			$Voting::TotalVotes++;
			%voteBar = $VotingBars[%bar];
			%voteBar.voteCount++;
		}
		
		else if(!%increaseVote) //Used for /ReVote
		{
			%voteBar = $VotingBars[%bar];
			%voteBar.voteCount++;
			$VotingBars[%previousBar].voteCount--;
		}
		
		for(%i = 0; %i < $Voting::BarCount; %i++)
		{
			%voteBar = $VotingBars[%i];
			%height = mFloatLength((%voteBar.voteCount / $Voting::TotalVotes) * 20, 2);
			
			if(%height > %voteBar.height || %voteBar.height $= "")
				dynamicVotingBarHeight(%i, %height, %voteBar.height);
			if(%height < %voteBar.height || %voteBar.height $= "")
				dynamicVotingBarHeight(%i, %height, %voteBar.height);
		}
	}
	
	function votingCleanup()
	{
		//Reset stuff and cleanup
		for(%i = 0; %i < $Voting::BarCount; %i++)
		{
			%bar = $VotingBars[%i];
			%barText = $VotingText[%i];
			
			//Delete all the shapes
			if(isObject(%bar))
				%bar.delete();
			if(isObject(%barText))
				%barText.delete();
			
			//Cancel the loop incase it's still running
			cancel(%bar.dynamicHeightLoop);
		}
		
		//Reset all the variables
		$Voting::IsVoting = 0;
		$Voting::EndVotes = 0;
		$Voting::TotalVotes = 0;
		$Voting::Session = "";
		$Voting::Options = "";
		$Voting::AdminLevel = 0;
		
		for(%i = 0; %i < ClientGroup.getCount(); %i++)
		{
			//Reset all the client variables
			%client = ClientGroup.getObject(%i);
			%client.hasVoted = 0;
			%client.hasReVoted = 0;
		}
		
		//Cancel the voting loop
		cancel($Voting::EndVoteLoop);
	}
	
	function endVotingSession()
	{
		announce("\c6The voting for \c4" @ $Voting::Session @ "\c6 has ended with a total of \c4" @ $Voting::TotalVotes @ " Votes\c6.");
		
		%winner = getVoteResults();
		
		if(getWordCount(%winner) > 1)
		{
			%winner = strReplace(%winner, " ", "\c6, \c4");
			%winner = strReplace(%winner, "_", " ");
			announce("\c6There was a tie between \c4" @ %winner @ " \c6with \c4" @ $Voting::EndVotes @ " Votes\c6.");
		}
		
		else
		{
			%winner = strReplace(%winner, "_", " ");
			announce("\c6The winning vote was \c4" @ %winner @ " \c6with \c4" @ $Voting::EndVotes @ " Votes\c6.");
		}
		votingCleanup();
	}
	
	function getVoteResults()
	{
		for(%i = 0; %i < $Voting::BarCount; %i++)
		{
			%bar = $VotingBars[%i];
			%votes = %bar.voteCount;
			
			if(%votes == %bestVotes && %bestVotes !$= "") //If they're the same, add it and say it's a tie
			{
				%bestVotes = %votes;
				%winner = %winner SPC getWord($Voting::Options,%i);
			}
			
			if(%votes > %bestVotes || %bestVotes $= "") //Set the %winner to the best
			{
				%bestVotes = %votes;
				%winner = getWord($Voting::Options,%i);
			}
		}
		$Voting::EndVotes = %bestVotes; //Our votes for the best choice
		return %winner; //Return the winner
	}
	
	function createVotingBars(%count)
	{
		%position = "10 124 100";	//The position
		%color[0] = "0 1 0 1";		//Green
		%color[1] = "1 0 0 1";		//Red
		%color[2] = "0 0 1 1";		//Blue
		%color[3] = "174 0 209 1";	//Some weird purple
		for(%i = 0; %i < %count; %i++)
		{
			%padPos = %position;
			
			//Here we have a bunch of stuff for centering it - Will try to make it better later on
			if(%i > 0 && %count == 2)
			{
				%padPos = vectorAdd(%position, "3 0 0");
				$VotingBars[0].setTransform(vectorAdd(%position, "-3 0 0"));
				$VotingBars[0].barPosition = vectorAdd(%position, "-3 0 0");
				$VotingText[0].setTransform(vectorAdd(%position, "-3 0 1"));
			}
			
			if(%i > 1 && %count == 3)
			{
				%padPos = vectorAdd(%position, "6 0 0");
				$VotingBars[0].setTransform(%position);
				$VotingBars[0].barPosition = vectorAdd(%position, "0 0 0");
				$VotingText[0].setTransform(vectorAdd(%position, "0 0 1"));
				$VotingBars[1].setTransform(vectorAdd(%position, "-6 0 0"));
				$VotingBars[1].barPosition = vectorAdd(%position, "-6 0 0");
				$VotingText[1].setTransform(vectorAdd(%position, "-6 0 1"));
			}
			
			if(%i > 2 && %count == 4)
			{
				%padPos = vectorAdd(%position, "9 0 0");
				$VotingBars[0].setTransform(vectorAdd(%position, "-3 0 0"));
				$VotingBars[0].barPosition = vectorAdd(%position, "-3 0 0");
				$VotingText[0].setTransform(vectorAdd(%position, "-3 0 1"));
				$VotingBars[1].setTransform(vectorAdd(%position, "-9 0 0"));
				$VotingBars[1].barPosition = vectorAdd(%position, "-9 0 0");
				$VotingText[1].setTransform(vectorAdd(%position, "-9 0 1"));
				$VotingBars[2].setTransform(vectorAdd(%position, "3 0 0"));
				$VotingBars[2].barPosition = vectorAdd(%position, "3 0 0");
				$VotingText[2].setTransform(vectorAdd(%position, "3 0 1"));
			}
			
			$VotingBars[%i] = new StaticShape() //Create the bar
			{
				dataBlock = votingBarShapeData;
				position = %padPos;		//Since this position is updated automatically...
				barPosition = %padPos;	//Use our own position tag so we can continue to get the original position
				color = %color[%i];		//The color
				voteCount = 0;			//The votes for this option
				height = 0;				//The height
				width = 3;				//The width
				length = 3;				//The length
			};
			
			$VotingBars[%i].setNodeColor("ALL", %color[%i]); //Set it to the color
			$VotingBars[%i].setScale($VotingBars[%i].length SPC $VotingBars[%i].width SPC $VotingBars[%i].height); //Set the scale
			
			$VotingText[%i] = new StaticShape() //Create the shape name for the bar
			{
				dataBlock = VotingTextEmptyShape;
				position = vectorAdd($VotingBars[%i].getPosition(), "0 0 1"); //Set its position one unit above the bar's
				text = strReplace(getWord($Voting::Options,%i), "_", " "); //Our own tag so we can check its text
			};
			
			$VotingText[%i].setScale("0.1 0.1 0.1"); //Set the scale to a small one (It's invisible anyway)
			$VotingText[%i].setShapeName($VotingText[%i].text); //Set the text of it
		}
		$Voting::BarCount = %count; //Set our global count
	}
	
	function dynamicVotingBarHeight(%bar, %height, %newHeight)
	{
		if(%newHeight < %height)
		{
			%speed = %height - %newHeight; //This gives us that gradual slow down effect
			%newHeight+= 0.1 * %speed;
		}
		
		if(%newHeight > %height)
		{
			%speed = %newHeight - %height;
			%newHeight-= 0.1 * %speed;
		}
		
		%voteBar = $VotingBars[%bar];	//The bar we want to change the height of
		%voteText = $VotingText[%bar];	//The bar's shape name
		if(isObject(%voteBar))			//If it exists
		{
			%pos = %voteBar.barPosition;			//We use our own position tag for positioning it
			%xy = getWords(%pos,0,1);				//The x and y
			%z = getWord(%voteBar.barPosition,2);	//The z
			%voteBar.height = %newHeight;			//Set the bar's height to the new height
			%barHeight = %voteBar.height/2;			//We divide by 2 to keep the bar's height kind of small
			%voteBar.setScale(%voteBar.length SPC %voteBar.width SPC %voteBar.height); //Set the scale
			%voteBar.setTransform(%xy SPC %barHeight + %z); //Then set the position so the bar stays in the same place
			
			%voteText.setTransform(vectorAdd(%voteBar.getPosition(), "0 0 " @ %barHeight)); //Update the shapename's position
			
			
			if(mFloatLength(%newHeight,2) == %height) //We round the new height and compare
			{
				%voteBar.height = %height;
				%barHeight = %voteBar.height/2;
				%voteBar.setScale(%voteBar.length SPC %voteBar.width SPC %voteBar.height);
				%voteBar.setTransform(%xy SPC %barHeight + %z);
				
				%voteText.setTransform(vectorAdd(%voteBar.getPosition(), "0 0 " @ %barHeight));
				
				cancel(%voteBar.dynamicHeightLoop);
				return;
			}
			
			cancel(%voteBar.dynamicHeightLoop); //Stops overlaps
			%voteBar.dynamicHeightLoop = schedule(10,0,dynamicVotingBarHeight,%bar,%height,%newHeight); //Loop it
		}
	}
};
activatePackage(Voting);