//+----------------------------------------+//
//+By Anthonyrules144, Eagle517 & Wrapperup+//
//+----------------------------------------+//

$Commands::loadLevelMod = 1;

exec("./Log.cs");
exec("./SupportOPT/Grab.cs");
exec("./SupportOPT/RotateMSG.cs");
exec("./SupportOPT/joined.cs");
schedule(10000, 0, exec("./SupportOPT/AddOns.cs"));

exec("./Main/Loadout.cs");

if($Commands::KnifeLoaded)
	return;
exec("./Knives/KnifeLoad.cs");
$Commands::KnifeLoaded = 1;
